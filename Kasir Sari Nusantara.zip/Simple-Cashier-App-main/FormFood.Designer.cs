﻿namespace ALP
{
    partial class FormFood
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel_sate = new System.Windows.Forms.Panel();
            this.btn_minSate = new System.Windows.Forms.Button();
            this.btn_addSate = new System.Windows.Forms.Button();
            this.lb_pSate = new System.Windows.Forms.Label();
            this.lb_sate = new System.Windows.Forms.Label();
            this.panel_soto = new System.Windows.Forms.Panel();
            this.btn_minSoto = new System.Windows.Forms.Button();
            this.btn_addSoto = new System.Windows.Forms.Button();
            this.lb_pSoto = new System.Windows.Forms.Label();
            this.lb_soto = new System.Windows.Forms.Label();
            this.panel_batagor = new System.Windows.Forms.Panel();
            this.btn_minBatagor = new System.Windows.Forms.Button();
            this.btn_addBatagor = new System.Windows.Forms.Button();
            this.lb_pBatagor = new System.Windows.Forms.Label();
            this.lb_batagor = new System.Windows.Forms.Label();
            this.panel_sopbun = new System.Windows.Forms.Panel();
            this.btn_minSopbun = new System.Windows.Forms.Button();
            this.btn_addSopbun = new System.Windows.Forms.Button();
            this.lb_pSopbun = new System.Windows.Forms.Label();
            this.lb_sopbun = new System.Windows.Forms.Label();
            this.panel_pecel = new System.Windows.Forms.Panel();
            this.btn_minPecel = new System.Windows.Forms.Button();
            this.btn_addPecel = new System.Windows.Forms.Button();
            this.lb_pPecel = new System.Windows.Forms.Label();
            this.lb_pecel = new System.Windows.Forms.Label();
            this.panel_miegor = new System.Windows.Forms.Panel();
            this.btn_minMiegor = new System.Windows.Forms.Button();
            this.btn_addMiegor = new System.Windows.Forms.Button();
            this.lb_pMiegor = new System.Windows.Forms.Label();
            this.lb_miegor = new System.Windows.Forms.Label();
            this.panel_rawon = new System.Windows.Forms.Panel();
            this.btn_minRawon = new System.Windows.Forms.Button();
            this.btn_addRawon = new System.Windows.Forms.Button();
            this.lb_pRawon = new System.Windows.Forms.Label();
            this.lb_rawon = new System.Windows.Forms.Label();
            this.panel_gadogado = new System.Windows.Forms.Panel();
            this.btn_minGadogado = new System.Windows.Forms.Button();
            this.btn_addGadogado = new System.Windows.Forms.Button();
            this.lb_pGadogado = new System.Windows.Forms.Label();
            this.lb_gadogado = new System.Windows.Forms.Label();
            this.panel_nasgor = new System.Windows.Forms.Panel();
            this.btn_minNasgor = new System.Windows.Forms.Button();
            this.btn_addNasgor = new System.Windows.Forms.Button();
            this.lb_pNasgor = new System.Windows.Forms.Label();
            this.lb_nasgor = new System.Windows.Forms.Label();
            this.lb_staffID = new System.Windows.Forms.Label();
            this.lb_tableNo = new System.Windows.Forms.Label();
            this.btn_Next = new System.Windows.Forms.Button();
            this.tb_totalP = new System.Windows.Forms.TextBox();
            this.tb_totalQ = new System.Windows.Forms.TextBox();
            this.lb_totalP = new System.Windows.Forms.Label();
            this.lb_totalQ = new System.Windows.Forms.Label();
            this.dgv_pesanan = new System.Windows.Forms.DataGridView();
            this.lb_daftarP = new System.Windows.Forms.Label();
            this.lb_noTable = new System.Windows.Forms.Label();
            this.lb_ID = new System.Windows.Forms.Label();
            this.panel_nasi = new System.Windows.Forms.Panel();
            this.btn_minNasi = new System.Windows.Forms.Button();
            this.btn_addNasi = new System.Windows.Forms.Button();
            this.lb_pNasi = new System.Windows.Forms.Label();
            this.lb_nasi = new System.Windows.Forms.Label();
            this.panel_bakso = new System.Windows.Forms.Panel();
            this.btn_minBakso = new System.Windows.Forms.Button();
            this.btn_addBakso = new System.Windows.Forms.Button();
            this.lb_pBakso = new System.Windows.Forms.Label();
            this.lb_bakso = new System.Windows.Forms.Label();
            this.panel_aypen = new System.Windows.Forms.Panel();
            this.btn_minAypen = new System.Windows.Forms.Button();
            this.btn_addAypen = new System.Windows.Forms.Button();
            this.lb_pAypen = new System.Windows.Forms.Label();
            this.lb_aypen = new System.Windows.Forms.Label();
            this.panel_bakwan = new System.Windows.Forms.Panel();
            this.btn_minBakwan = new System.Windows.Forms.Button();
            this.btn_addBakwan = new System.Windows.Forms.Button();
            this.lb_pBakwan = new System.Windows.Forms.Label();
            this.lb_bakwan = new System.Windows.Forms.Label();
            this.panel_empal = new System.Windows.Forms.Panel();
            this.btn_minEmpal = new System.Windows.Forms.Button();
            this.btn_addEmpal = new System.Windows.Forms.Button();
            this.lb_pEmpal = new System.Windows.Forms.Label();
            this.lb_empal = new System.Windows.Forms.Label();
            this.panel_aygor = new System.Windows.Forms.Panel();
            this.btn_minAygor = new System.Windows.Forms.Button();
            this.btn_addAygor = new System.Windows.Forms.Button();
            this.lb_pAygor = new System.Windows.Forms.Label();
            this.lb_aygor = new System.Windows.Forms.Label();
            this.panel_nascam = new System.Windows.Forms.Panel();
            this.btn_minNascam = new System.Windows.Forms.Button();
            this.btn_addNascam = new System.Windows.Forms.Button();
            this.lb_pNascam = new System.Windows.Forms.Label();
            this.lb_nascam = new System.Windows.Forms.Label();
            this.stat_date = new System.Windows.Forms.StatusStrip();
            this.dateStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.timer_kasir = new System.Windows.Forms.Timer(this.components);
            this.pb_nasi = new System.Windows.Forms.PictureBox();
            this.pb_bakso = new System.Windows.Forms.PictureBox();
            this.pb_aypen = new System.Windows.Forms.PictureBox();
            this.pb_bawkan = new System.Windows.Forms.PictureBox();
            this.pb_empal = new System.Windows.Forms.PictureBox();
            this.pb_aygor = new System.Windows.Forms.PictureBox();
            this.pb_nascam = new System.Windows.Forms.PictureBox();
            this.pb_sate = new System.Windows.Forms.PictureBox();
            this.pb_soto = new System.Windows.Forms.PictureBox();
            this.pb_batagor = new System.Windows.Forms.PictureBox();
            this.pb_sopbun = new System.Windows.Forms.PictureBox();
            this.pb_pecel = new System.Windows.Forms.PictureBox();
            this.pb_miegor = new System.Windows.Forms.PictureBox();
            this.pb_rawon = new System.Windows.Forms.PictureBox();
            this.pb_gadogado = new System.Windows.Forms.PictureBox();
            this.pb_nasgor = new System.Windows.Forms.PictureBox();
            this.panel_sate.SuspendLayout();
            this.panel_soto.SuspendLayout();
            this.panel_batagor.SuspendLayout();
            this.panel_sopbun.SuspendLayout();
            this.panel_pecel.SuspendLayout();
            this.panel_miegor.SuspendLayout();
            this.panel_rawon.SuspendLayout();
            this.panel_gadogado.SuspendLayout();
            this.panel_nasgor.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_pesanan)).BeginInit();
            this.panel_nasi.SuspendLayout();
            this.panel_bakso.SuspendLayout();
            this.panel_aypen.SuspendLayout();
            this.panel_bakwan.SuspendLayout();
            this.panel_empal.SuspendLayout();
            this.panel_aygor.SuspendLayout();
            this.panel_nascam.SuspendLayout();
            this.stat_date.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_nasi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_bakso)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_aypen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_bawkan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_empal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_aygor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_nascam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_sate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_soto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_batagor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_sopbun)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_pecel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_miegor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_rawon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_gadogado)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_nasgor)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_sate
            // 
            this.panel_sate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel_sate.Controls.Add(this.btn_minSate);
            this.panel_sate.Controls.Add(this.btn_addSate);
            this.panel_sate.Controls.Add(this.lb_pSate);
            this.panel_sate.Controls.Add(this.lb_sate);
            this.panel_sate.Controls.Add(this.pb_sate);
            this.panel_sate.Location = new System.Drawing.Point(418, 988);
            this.panel_sate.Name = "panel_sate";
            this.panel_sate.Size = new System.Drawing.Size(170, 228);
            this.panel_sate.TabIndex = 54;
            // 
            // btn_minSate
            // 
            this.btn_minSate.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_minSate.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_minSate.Location = new System.Drawing.Point(87, 186);
            this.btn_minSate.Name = "btn_minSate";
            this.btn_minSate.Size = new System.Drawing.Size(40, 41);
            this.btn_minSate.TabIndex = 25;
            this.btn_minSate.Text = "-";
            this.btn_minSate.UseVisualStyleBackColor = false;
            this.btn_minSate.Click += new System.EventHandler(this.btn_minSate_Click);
            // 
            // btn_addSate
            // 
            this.btn_addSate.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_addSate.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_addSate.Location = new System.Drawing.Point(46, 186);
            this.btn_addSate.Name = "btn_addSate";
            this.btn_addSate.Size = new System.Drawing.Size(40, 41);
            this.btn_addSate.TabIndex = 24;
            this.btn_addSate.Text = "+";
            this.btn_addSate.UseVisualStyleBackColor = false;
            this.btn_addSate.Click += new System.EventHandler(this.btn_addSate_Click);
            // 
            // lb_pSate
            // 
            this.lb_pSate.AutoSize = true;
            this.lb_pSate.Location = new System.Drawing.Point(14, 159);
            this.lb_pSate.Name = "lb_pSate";
            this.lb_pSate.Size = new System.Drawing.Size(141, 25);
            this.lb_pSate.TabIndex = 23;
            this.lb_pSate.Text = "Rp 35.000,00";
            // 
            // lb_sate
            // 
            this.lb_sate.AutoSize = true;
            this.lb_sate.Location = new System.Drawing.Point(27, 130);
            this.lb_sate.Name = "lb_sate";
            this.lb_sate.Size = new System.Drawing.Size(116, 25);
            this.lb_sate.TabIndex = 22;
            this.lb_sate.Text = "Sate Ayam";
            // 
            // panel_soto
            // 
            this.panel_soto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel_soto.Controls.Add(this.btn_minSoto);
            this.panel_soto.Controls.Add(this.btn_addSoto);
            this.panel_soto.Controls.Add(this.lb_pSoto);
            this.panel_soto.Controls.Add(this.lb_soto);
            this.panel_soto.Controls.Add(this.pb_soto);
            this.panel_soto.Location = new System.Drawing.Point(418, 745);
            this.panel_soto.Name = "panel_soto";
            this.panel_soto.Size = new System.Drawing.Size(170, 228);
            this.panel_soto.TabIndex = 51;
            // 
            // btn_minSoto
            // 
            this.btn_minSoto.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_minSoto.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_minSoto.Location = new System.Drawing.Point(87, 186);
            this.btn_minSoto.Name = "btn_minSoto";
            this.btn_minSoto.Size = new System.Drawing.Size(40, 41);
            this.btn_minSoto.TabIndex = 25;
            this.btn_minSoto.Text = "-";
            this.btn_minSoto.UseVisualStyleBackColor = false;
            this.btn_minSoto.Click += new System.EventHandler(this.btn_minSoto_Click);
            // 
            // btn_addSoto
            // 
            this.btn_addSoto.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_addSoto.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_addSoto.Location = new System.Drawing.Point(46, 186);
            this.btn_addSoto.Name = "btn_addSoto";
            this.btn_addSoto.Size = new System.Drawing.Size(40, 41);
            this.btn_addSoto.TabIndex = 24;
            this.btn_addSoto.Text = "+";
            this.btn_addSoto.UseVisualStyleBackColor = false;
            this.btn_addSoto.Click += new System.EventHandler(this.btn_addSoto_Click);
            // 
            // lb_pSoto
            // 
            this.lb_pSoto.AutoSize = true;
            this.lb_pSoto.Location = new System.Drawing.Point(14, 159);
            this.lb_pSoto.Name = "lb_pSoto";
            this.lb_pSoto.Size = new System.Drawing.Size(141, 25);
            this.lb_pSoto.TabIndex = 23;
            this.lb_pSoto.Text = "Rp 35.000,00";
            // 
            // lb_soto
            // 
            this.lb_soto.AutoSize = true;
            this.lb_soto.Location = new System.Drawing.Point(34, 130);
            this.lb_soto.Name = "lb_soto";
            this.lb_soto.Size = new System.Drawing.Size(97, 25);
            this.lb_soto.TabIndex = 22;
            this.lb_soto.Text = "Soto Mie";
            // 
            // panel_batagor
            // 
            this.panel_batagor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel_batagor.Controls.Add(this.btn_minBatagor);
            this.panel_batagor.Controls.Add(this.btn_addBatagor);
            this.panel_batagor.Controls.Add(this.lb_pBatagor);
            this.panel_batagor.Controls.Add(this.lb_batagor);
            this.panel_batagor.Controls.Add(this.pb_batagor);
            this.panel_batagor.Location = new System.Drawing.Point(418, 505);
            this.panel_batagor.Name = "panel_batagor";
            this.panel_batagor.Size = new System.Drawing.Size(170, 228);
            this.panel_batagor.TabIndex = 48;
            // 
            // btn_minBatagor
            // 
            this.btn_minBatagor.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_minBatagor.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_minBatagor.Location = new System.Drawing.Point(87, 186);
            this.btn_minBatagor.Name = "btn_minBatagor";
            this.btn_minBatagor.Size = new System.Drawing.Size(40, 41);
            this.btn_minBatagor.TabIndex = 25;
            this.btn_minBatagor.Text = "-";
            this.btn_minBatagor.UseVisualStyleBackColor = false;
            this.btn_minBatagor.Click += new System.EventHandler(this.btn_minBatagor_Click);
            // 
            // btn_addBatagor
            // 
            this.btn_addBatagor.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_addBatagor.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_addBatagor.Location = new System.Drawing.Point(46, 186);
            this.btn_addBatagor.Name = "btn_addBatagor";
            this.btn_addBatagor.Size = new System.Drawing.Size(40, 41);
            this.btn_addBatagor.TabIndex = 24;
            this.btn_addBatagor.Text = "+";
            this.btn_addBatagor.UseVisualStyleBackColor = false;
            this.btn_addBatagor.Click += new System.EventHandler(this.btn_addBatagor_Click);
            // 
            // lb_pBatagor
            // 
            this.lb_pBatagor.AutoSize = true;
            this.lb_pBatagor.Location = new System.Drawing.Point(14, 159);
            this.lb_pBatagor.Name = "lb_pBatagor";
            this.lb_pBatagor.Size = new System.Drawing.Size(141, 25);
            this.lb_pBatagor.TabIndex = 23;
            this.lb_pBatagor.Text = "Rp 30.000,00";
            // 
            // lb_batagor
            // 
            this.lb_batagor.AutoSize = true;
            this.lb_batagor.Location = new System.Drawing.Point(42, 130);
            this.lb_batagor.Name = "lb_batagor";
            this.lb_batagor.Size = new System.Drawing.Size(87, 25);
            this.lb_batagor.TabIndex = 22;
            this.lb_batagor.Text = "Batagor";
            // 
            // panel_sopbun
            // 
            this.panel_sopbun.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel_sopbun.Controls.Add(this.btn_minSopbun);
            this.panel_sopbun.Controls.Add(this.btn_addSopbun);
            this.panel_sopbun.Controls.Add(this.lb_pSopbun);
            this.panel_sopbun.Controls.Add(this.lb_sopbun);
            this.panel_sopbun.Controls.Add(this.pb_sopbun);
            this.panel_sopbun.Location = new System.Drawing.Point(234, 988);
            this.panel_sopbun.Name = "panel_sopbun";
            this.panel_sopbun.Size = new System.Drawing.Size(170, 228);
            this.panel_sopbun.TabIndex = 53;
            // 
            // btn_minSopbun
            // 
            this.btn_minSopbun.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_minSopbun.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_minSopbun.Location = new System.Drawing.Point(87, 186);
            this.btn_minSopbun.Name = "btn_minSopbun";
            this.btn_minSopbun.Size = new System.Drawing.Size(40, 41);
            this.btn_minSopbun.TabIndex = 25;
            this.btn_minSopbun.Text = "-";
            this.btn_minSopbun.UseVisualStyleBackColor = false;
            this.btn_minSopbun.Click += new System.EventHandler(this.btn_minSopbun_Click);
            // 
            // btn_addSopbun
            // 
            this.btn_addSopbun.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_addSopbun.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_addSopbun.Location = new System.Drawing.Point(46, 186);
            this.btn_addSopbun.Name = "btn_addSopbun";
            this.btn_addSopbun.Size = new System.Drawing.Size(40, 41);
            this.btn_addSopbun.TabIndex = 24;
            this.btn_addSopbun.Text = "+";
            this.btn_addSopbun.UseVisualStyleBackColor = false;
            this.btn_addSopbun.Click += new System.EventHandler(this.btn_addSopbun_Click);
            // 
            // lb_pSopbun
            // 
            this.lb_pSopbun.AutoSize = true;
            this.lb_pSopbun.Location = new System.Drawing.Point(14, 159);
            this.lb_pSopbun.Name = "lb_pSopbun";
            this.lb_pSopbun.Size = new System.Drawing.Size(141, 25);
            this.lb_pSopbun.TabIndex = 23;
            this.lb_pSopbun.Text = "Rp 50.000,00";
            // 
            // lb_sopbun
            // 
            this.lb_sopbun.AutoSize = true;
            this.lb_sopbun.Location = new System.Drawing.Point(26, 130);
            this.lb_sopbun.Name = "lb_sopbun";
            this.lb_sopbun.Size = new System.Drawing.Size(118, 25);
            this.lb_sopbun.TabIndex = 22;
            this.lb_sopbun.Text = "Sop Buntut";
            // 
            // panel_pecel
            // 
            this.panel_pecel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel_pecel.Controls.Add(this.btn_minPecel);
            this.panel_pecel.Controls.Add(this.btn_addPecel);
            this.panel_pecel.Controls.Add(this.lb_pPecel);
            this.panel_pecel.Controls.Add(this.lb_pecel);
            this.panel_pecel.Controls.Add(this.pb_pecel);
            this.panel_pecel.Location = new System.Drawing.Point(234, 745);
            this.panel_pecel.Name = "panel_pecel";
            this.panel_pecel.Size = new System.Drawing.Size(170, 228);
            this.panel_pecel.TabIndex = 50;
            // 
            // btn_minPecel
            // 
            this.btn_minPecel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_minPecel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_minPecel.Location = new System.Drawing.Point(87, 186);
            this.btn_minPecel.Name = "btn_minPecel";
            this.btn_minPecel.Size = new System.Drawing.Size(40, 41);
            this.btn_minPecel.TabIndex = 25;
            this.btn_minPecel.Text = "-";
            this.btn_minPecel.UseVisualStyleBackColor = false;
            this.btn_minPecel.Click += new System.EventHandler(this.btn_minPecel_Click);
            // 
            // btn_addPecel
            // 
            this.btn_addPecel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_addPecel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_addPecel.Location = new System.Drawing.Point(46, 186);
            this.btn_addPecel.Name = "btn_addPecel";
            this.btn_addPecel.Size = new System.Drawing.Size(40, 41);
            this.btn_addPecel.TabIndex = 24;
            this.btn_addPecel.Text = "+";
            this.btn_addPecel.UseVisualStyleBackColor = false;
            this.btn_addPecel.Click += new System.EventHandler(this.btn_addPecel_Click);
            // 
            // lb_pPecel
            // 
            this.lb_pPecel.AutoSize = true;
            this.lb_pPecel.Location = new System.Drawing.Point(14, 159);
            this.lb_pPecel.Name = "lb_pPecel";
            this.lb_pPecel.Size = new System.Drawing.Size(141, 25);
            this.lb_pPecel.TabIndex = 23;
            this.lb_pPecel.Text = "Rp 30.000,00";
            // 
            // lb_pecel
            // 
            this.lb_pecel.AutoSize = true;
            this.lb_pecel.Location = new System.Drawing.Point(26, 130);
            this.lb_pecel.Name = "lb_pecel";
            this.lb_pecel.Size = new System.Drawing.Size(115, 25);
            this.lb_pecel.TabIndex = 22;
            this.lb_pecel.Text = "Nasi Pecel";
            // 
            // panel_miegor
            // 
            this.panel_miegor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel_miegor.Controls.Add(this.btn_minMiegor);
            this.panel_miegor.Controls.Add(this.btn_addMiegor);
            this.panel_miegor.Controls.Add(this.lb_pMiegor);
            this.panel_miegor.Controls.Add(this.lb_miegor);
            this.panel_miegor.Controls.Add(this.pb_miegor);
            this.panel_miegor.Location = new System.Drawing.Point(234, 505);
            this.panel_miegor.Name = "panel_miegor";
            this.panel_miegor.Size = new System.Drawing.Size(170, 228);
            this.panel_miegor.TabIndex = 47;
            // 
            // btn_minMiegor
            // 
            this.btn_minMiegor.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_minMiegor.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_minMiegor.Location = new System.Drawing.Point(87, 186);
            this.btn_minMiegor.Name = "btn_minMiegor";
            this.btn_minMiegor.Size = new System.Drawing.Size(40, 41);
            this.btn_minMiegor.TabIndex = 25;
            this.btn_minMiegor.Text = "-";
            this.btn_minMiegor.UseVisualStyleBackColor = false;
            this.btn_minMiegor.Click += new System.EventHandler(this.btn_minMiegor_Click);
            // 
            // btn_addMiegor
            // 
            this.btn_addMiegor.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_addMiegor.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_addMiegor.Location = new System.Drawing.Point(46, 186);
            this.btn_addMiegor.Name = "btn_addMiegor";
            this.btn_addMiegor.Size = new System.Drawing.Size(40, 41);
            this.btn_addMiegor.TabIndex = 24;
            this.btn_addMiegor.Text = "+";
            this.btn_addMiegor.UseVisualStyleBackColor = false;
            this.btn_addMiegor.Click += new System.EventHandler(this.btn_addMiegor_Click);
            // 
            // lb_pMiegor
            // 
            this.lb_pMiegor.AutoSize = true;
            this.lb_pMiegor.Location = new System.Drawing.Point(14, 159);
            this.lb_pMiegor.Name = "lb_pMiegor";
            this.lb_pMiegor.Size = new System.Drawing.Size(141, 25);
            this.lb_pMiegor.TabIndex = 23;
            this.lb_pMiegor.Text = "Rp 35.000,00";
            // 
            // lb_miegor
            // 
            this.lb_miegor.AutoSize = true;
            this.lb_miegor.Location = new System.Drawing.Point(22, 130);
            this.lb_miegor.Name = "lb_miegor";
            this.lb_miegor.Size = new System.Drawing.Size(124, 25);
            this.lb_miegor.TabIndex = 22;
            this.lb_miegor.Text = "Mie Goreng";
            // 
            // panel_rawon
            // 
            this.panel_rawon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel_rawon.Controls.Add(this.btn_minRawon);
            this.panel_rawon.Controls.Add(this.btn_addRawon);
            this.panel_rawon.Controls.Add(this.lb_pRawon);
            this.panel_rawon.Controls.Add(this.lb_rawon);
            this.panel_rawon.Controls.Add(this.pb_rawon);
            this.panel_rawon.Location = new System.Drawing.Point(50, 988);
            this.panel_rawon.Name = "panel_rawon";
            this.panel_rawon.Size = new System.Drawing.Size(170, 228);
            this.panel_rawon.TabIndex = 52;
            // 
            // btn_minRawon
            // 
            this.btn_minRawon.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_minRawon.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_minRawon.Location = new System.Drawing.Point(87, 186);
            this.btn_minRawon.Name = "btn_minRawon";
            this.btn_minRawon.Size = new System.Drawing.Size(40, 41);
            this.btn_minRawon.TabIndex = 25;
            this.btn_minRawon.Text = "-";
            this.btn_minRawon.UseVisualStyleBackColor = false;
            this.btn_minRawon.Click += new System.EventHandler(this.btn_minRawon_Click);
            // 
            // btn_addRawon
            // 
            this.btn_addRawon.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_addRawon.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_addRawon.Location = new System.Drawing.Point(46, 186);
            this.btn_addRawon.Name = "btn_addRawon";
            this.btn_addRawon.Size = new System.Drawing.Size(40, 41);
            this.btn_addRawon.TabIndex = 24;
            this.btn_addRawon.Text = "+";
            this.btn_addRawon.UseVisualStyleBackColor = false;
            this.btn_addRawon.Click += new System.EventHandler(this.btn_addRawon_Click);
            // 
            // lb_pRawon
            // 
            this.lb_pRawon.AutoSize = true;
            this.lb_pRawon.Location = new System.Drawing.Point(14, 159);
            this.lb_pRawon.Name = "lb_pRawon";
            this.lb_pRawon.Size = new System.Drawing.Size(141, 25);
            this.lb_pRawon.TabIndex = 23;
            this.lb_pRawon.Text = "Rp 40.000,00";
            // 
            // lb_rawon
            // 
            this.lb_rawon.AutoSize = true;
            this.lb_rawon.Location = new System.Drawing.Point(21, 130);
            this.lb_rawon.Name = "lb_rawon";
            this.lb_rawon.Size = new System.Drawing.Size(127, 25);
            this.lb_rawon.TabIndex = 22;
            this.lb_rawon.Text = "Nasi Rawon";
            // 
            // panel_gadogado
            // 
            this.panel_gadogado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel_gadogado.Controls.Add(this.btn_minGadogado);
            this.panel_gadogado.Controls.Add(this.btn_addGadogado);
            this.panel_gadogado.Controls.Add(this.lb_pGadogado);
            this.panel_gadogado.Controls.Add(this.lb_gadogado);
            this.panel_gadogado.Controls.Add(this.pb_gadogado);
            this.panel_gadogado.Location = new System.Drawing.Point(50, 745);
            this.panel_gadogado.Name = "panel_gadogado";
            this.panel_gadogado.Size = new System.Drawing.Size(170, 228);
            this.panel_gadogado.TabIndex = 49;
            // 
            // btn_minGadogado
            // 
            this.btn_minGadogado.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_minGadogado.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_minGadogado.Location = new System.Drawing.Point(87, 186);
            this.btn_minGadogado.Name = "btn_minGadogado";
            this.btn_minGadogado.Size = new System.Drawing.Size(40, 41);
            this.btn_minGadogado.TabIndex = 25;
            this.btn_minGadogado.Text = "-";
            this.btn_minGadogado.UseVisualStyleBackColor = false;
            this.btn_minGadogado.Click += new System.EventHandler(this.btn_minGadogado_Click);
            // 
            // btn_addGadogado
            // 
            this.btn_addGadogado.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_addGadogado.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_addGadogado.Location = new System.Drawing.Point(46, 186);
            this.btn_addGadogado.Name = "btn_addGadogado";
            this.btn_addGadogado.Size = new System.Drawing.Size(40, 41);
            this.btn_addGadogado.TabIndex = 24;
            this.btn_addGadogado.Text = "+";
            this.btn_addGadogado.UseVisualStyleBackColor = false;
            this.btn_addGadogado.Click += new System.EventHandler(this.btn_addGadogado_Click);
            // 
            // lb_pGadogado
            // 
            this.lb_pGadogado.AutoSize = true;
            this.lb_pGadogado.Location = new System.Drawing.Point(14, 159);
            this.lb_pGadogado.Name = "lb_pGadogado";
            this.lb_pGadogado.Size = new System.Drawing.Size(141, 25);
            this.lb_pGadogado.TabIndex = 23;
            this.lb_pGadogado.Text = "Rp 30.000,00";
            // 
            // lb_gadogado
            // 
            this.lb_gadogado.AutoSize = true;
            this.lb_gadogado.Location = new System.Drawing.Point(20, 130);
            this.lb_gadogado.Name = "lb_gadogado";
            this.lb_gadogado.Size = new System.Drawing.Size(123, 25);
            this.lb_gadogado.TabIndex = 22;
            this.lb_gadogado.Text = "Gado-Gado";
            // 
            // panel_nasgor
            // 
            this.panel_nasgor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel_nasgor.Controls.Add(this.btn_minNasgor);
            this.panel_nasgor.Controls.Add(this.btn_addNasgor);
            this.panel_nasgor.Controls.Add(this.lb_pNasgor);
            this.panel_nasgor.Controls.Add(this.lb_nasgor);
            this.panel_nasgor.Controls.Add(this.pb_nasgor);
            this.panel_nasgor.Location = new System.Drawing.Point(50, 505);
            this.panel_nasgor.Name = "panel_nasgor";
            this.panel_nasgor.Size = new System.Drawing.Size(170, 228);
            this.panel_nasgor.TabIndex = 46;
            // 
            // btn_minNasgor
            // 
            this.btn_minNasgor.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_minNasgor.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_minNasgor.Location = new System.Drawing.Point(87, 186);
            this.btn_minNasgor.Name = "btn_minNasgor";
            this.btn_minNasgor.Size = new System.Drawing.Size(40, 41);
            this.btn_minNasgor.TabIndex = 25;
            this.btn_minNasgor.Text = "-";
            this.btn_minNasgor.UseVisualStyleBackColor = false;
            this.btn_minNasgor.Click += new System.EventHandler(this.btn_minNasgor_Click);
            // 
            // btn_addNasgor
            // 
            this.btn_addNasgor.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_addNasgor.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_addNasgor.Location = new System.Drawing.Point(46, 186);
            this.btn_addNasgor.Name = "btn_addNasgor";
            this.btn_addNasgor.Size = new System.Drawing.Size(40, 41);
            this.btn_addNasgor.TabIndex = 24;
            this.btn_addNasgor.Text = "+";
            this.btn_addNasgor.UseVisualStyleBackColor = false;
            this.btn_addNasgor.Click += new System.EventHandler(this.btn_addNasgor_Click);
            // 
            // lb_pNasgor
            // 
            this.lb_pNasgor.AutoSize = true;
            this.lb_pNasgor.Location = new System.Drawing.Point(14, 159);
            this.lb_pNasgor.Name = "lb_pNasgor";
            this.lb_pNasgor.Size = new System.Drawing.Size(141, 25);
            this.lb_pNasgor.TabIndex = 23;
            this.lb_pNasgor.Text = "Rp 35.000,00";
            // 
            // lb_nasgor
            // 
            this.lb_nasgor.AutoSize = true;
            this.lb_nasgor.Location = new System.Drawing.Point(20, 130);
            this.lb_nasgor.Name = "lb_nasgor";
            this.lb_nasgor.Size = new System.Drawing.Size(132, 25);
            this.lb_nasgor.TabIndex = 22;
            this.lb_nasgor.Text = "Nasi Goreng";
            // 
            // lb_staffID
            // 
            this.lb_staffID.AutoSize = true;
            this.lb_staffID.Location = new System.Drawing.Point(1023, 505);
            this.lb_staffID.Name = "lb_staffID";
            this.lb_staffID.Size = new System.Drawing.Size(19, 25);
            this.lb_staffID.TabIndex = 45;
            this.lb_staffID.Text = "-";
            // 
            // lb_tableNo
            // 
            this.lb_tableNo.AutoSize = true;
            this.lb_tableNo.Location = new System.Drawing.Point(1078, 552);
            this.lb_tableNo.Name = "lb_tableNo";
            this.lb_tableNo.Size = new System.Drawing.Size(19, 25);
            this.lb_tableNo.TabIndex = 44;
            this.lb_tableNo.Text = "-";
            // 
            // btn_Next
            // 
            this.btn_Next.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btn_Next.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Next.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Next.Location = new System.Drawing.Point(789, 1169);
            this.btn_Next.Name = "btn_Next";
            this.btn_Next.Size = new System.Drawing.Size(116, 41);
            this.btn_Next.TabIndex = 43;
            this.btn_Next.Text = "Next";
            this.btn_Next.UseVisualStyleBackColor = false;
            this.btn_Next.Click += new System.EventHandler(this.btn_Next_Click);
            // 
            // tb_totalP
            // 
            this.tb_totalP.Enabled = false;
            this.tb_totalP.Location = new System.Drawing.Point(789, 1120);
            this.tb_totalP.Name = "tb_totalP";
            this.tb_totalP.Size = new System.Drawing.Size(188, 31);
            this.tb_totalP.TabIndex = 42;
            // 
            // tb_totalQ
            // 
            this.tb_totalQ.Enabled = false;
            this.tb_totalQ.Location = new System.Drawing.Point(789, 1080);
            this.tb_totalQ.Name = "tb_totalQ";
            this.tb_totalQ.Size = new System.Drawing.Size(188, 31);
            this.tb_totalQ.TabIndex = 41;
            // 
            // lb_totalP
            // 
            this.lb_totalP.AutoSize = true;
            this.lb_totalP.Location = new System.Drawing.Point(630, 1120);
            this.lb_totalP.Name = "lb_totalP";
            this.lb_totalP.Size = new System.Drawing.Size(121, 25);
            this.lb_totalP.TabIndex = 40;
            this.lb_totalP.Text = "Total Price:";
            // 
            // lb_totalQ
            // 
            this.lb_totalQ.AutoSize = true;
            this.lb_totalQ.Location = new System.Drawing.Point(630, 1080);
            this.lb_totalQ.Name = "lb_totalQ";
            this.lb_totalQ.Size = new System.Drawing.Size(152, 25);
            this.lb_totalQ.TabIndex = 39;
            this.lb_totalQ.Text = "Total Quantity:";
            // 
            // dgv_pesanan
            // 
            this.dgv_pesanan.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv_pesanan.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_pesanan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_pesanan.Location = new System.Drawing.Point(634, 636);
            this.dgv_pesanan.Name = "dgv_pesanan";
            this.dgv_pesanan.ReadOnly = true;
            this.dgv_pesanan.RowHeadersVisible = false;
            this.dgv_pesanan.RowHeadersWidth = 82;
            this.dgv_pesanan.RowTemplate.Height = 33;
            this.dgv_pesanan.Size = new System.Drawing.Size(651, 425);
            this.dgv_pesanan.TabIndex = 38;
            // 
            // lb_daftarP
            // 
            this.lb_daftarP.AutoSize = true;
            this.lb_daftarP.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_daftarP.Location = new System.Drawing.Point(630, 592);
            this.lb_daftarP.Name = "lb_daftarP";
            this.lb_daftarP.Size = new System.Drawing.Size(182, 25);
            this.lb_daftarP.TabIndex = 37;
            this.lb_daftarP.Text = "Daftar Pesanan:";
            // 
            // lb_noTable
            // 
            this.lb_noTable.AutoSize = true;
            this.lb_noTable.Location = new System.Drawing.Point(930, 550);
            this.lb_noTable.Name = "lb_noTable";
            this.lb_noTable.Size = new System.Drawing.Size(153, 25);
            this.lb_noTable.TabIndex = 36;
            this.lb_noTable.Text = "Table Number:";
            // 
            // lb_ID
            // 
            this.lb_ID.AutoSize = true;
            this.lb_ID.Location = new System.Drawing.Point(930, 505);
            this.lb_ID.Name = "lb_ID";
            this.lb_ID.Size = new System.Drawing.Size(88, 25);
            this.lb_ID.TabIndex = 35;
            this.lb_ID.Text = "Staff ID:";
            // 
            // panel_nasi
            // 
            this.panel_nasi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel_nasi.Controls.Add(this.btn_minNasi);
            this.panel_nasi.Controls.Add(this.btn_addNasi);
            this.panel_nasi.Controls.Add(this.lb_pNasi);
            this.panel_nasi.Controls.Add(this.lb_nasi);
            this.panel_nasi.Controls.Add(this.pb_nasi);
            this.panel_nasi.Location = new System.Drawing.Point(48, 1709);
            this.panel_nasi.Name = "panel_nasi";
            this.panel_nasi.Size = new System.Drawing.Size(170, 228);
            this.panel_nasi.TabIndex = 61;
            // 
            // btn_minNasi
            // 
            this.btn_minNasi.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_minNasi.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_minNasi.Location = new System.Drawing.Point(87, 186);
            this.btn_minNasi.Name = "btn_minNasi";
            this.btn_minNasi.Size = new System.Drawing.Size(40, 41);
            this.btn_minNasi.TabIndex = 25;
            this.btn_minNasi.Text = "-";
            this.btn_minNasi.UseVisualStyleBackColor = false;
            this.btn_minNasi.Click += new System.EventHandler(this.btn_minNasi_Click);
            // 
            // btn_addNasi
            // 
            this.btn_addNasi.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_addNasi.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_addNasi.Location = new System.Drawing.Point(46, 186);
            this.btn_addNasi.Name = "btn_addNasi";
            this.btn_addNasi.Size = new System.Drawing.Size(40, 41);
            this.btn_addNasi.TabIndex = 24;
            this.btn_addNasi.Text = "+";
            this.btn_addNasi.UseVisualStyleBackColor = false;
            this.btn_addNasi.Click += new System.EventHandler(this.btn_addNasi_Click);
            // 
            // lb_pNasi
            // 
            this.lb_pNasi.AutoSize = true;
            this.lb_pNasi.Location = new System.Drawing.Point(18, 159);
            this.lb_pNasi.Name = "lb_pNasi";
            this.lb_pNasi.Size = new System.Drawing.Size(129, 25);
            this.lb_pNasi.TabIndex = 23;
            this.lb_pNasi.Text = "Rp 8.000,00";
            // 
            // lb_nasi
            // 
            this.lb_nasi.AutoSize = true;
            this.lb_nasi.Location = new System.Drawing.Point(27, 130);
            this.lb_nasi.Name = "lb_nasi";
            this.lb_nasi.Size = new System.Drawing.Size(110, 25);
            this.lb_nasi.TabIndex = 22;
            this.lb_nasi.Text = "Nasi Putih";
            // 
            // panel_bakso
            // 
            this.panel_bakso.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel_bakso.Controls.Add(this.btn_minBakso);
            this.panel_bakso.Controls.Add(this.btn_addBakso);
            this.panel_bakso.Controls.Add(this.lb_pBakso);
            this.panel_bakso.Controls.Add(this.lb_bakso);
            this.panel_bakso.Controls.Add(this.pb_bakso);
            this.panel_bakso.Location = new System.Drawing.Point(417, 1467);
            this.panel_bakso.Name = "panel_bakso";
            this.panel_bakso.Size = new System.Drawing.Size(170, 228);
            this.panel_bakso.TabIndex = 60;
            // 
            // btn_minBakso
            // 
            this.btn_minBakso.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_minBakso.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_minBakso.Location = new System.Drawing.Point(87, 186);
            this.btn_minBakso.Name = "btn_minBakso";
            this.btn_minBakso.Size = new System.Drawing.Size(40, 41);
            this.btn_minBakso.TabIndex = 25;
            this.btn_minBakso.Text = "-";
            this.btn_minBakso.UseVisualStyleBackColor = false;
            this.btn_minBakso.Click += new System.EventHandler(this.btn_minBakso_Click);
            // 
            // btn_addBakso
            // 
            this.btn_addBakso.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_addBakso.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_addBakso.Location = new System.Drawing.Point(46, 186);
            this.btn_addBakso.Name = "btn_addBakso";
            this.btn_addBakso.Size = new System.Drawing.Size(40, 41);
            this.btn_addBakso.TabIndex = 24;
            this.btn_addBakso.Text = "+";
            this.btn_addBakso.UseVisualStyleBackColor = false;
            this.btn_addBakso.Click += new System.EventHandler(this.btn_addBakso_Click);
            // 
            // lb_pBakso
            // 
            this.lb_pBakso.AutoSize = true;
            this.lb_pBakso.Location = new System.Drawing.Point(14, 159);
            this.lb_pBakso.Name = "lb_pBakso";
            this.lb_pBakso.Size = new System.Drawing.Size(141, 25);
            this.lb_pBakso.TabIndex = 23;
            this.lb_pBakso.Text = "Rp 30.000,00";
            // 
            // lb_bakso
            // 
            this.lb_bakso.AutoSize = true;
            this.lb_bakso.Location = new System.Drawing.Point(26, 130);
            this.lb_bakso.Name = "lb_bakso";
            this.lb_bakso.Size = new System.Drawing.Size(121, 25);
            this.lb_bakso.TabIndex = 22;
            this.lb_bakso.Text = "Bakso Sapi";
            // 
            // panel_aypen
            // 
            this.panel_aypen.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel_aypen.Controls.Add(this.btn_minAypen);
            this.panel_aypen.Controls.Add(this.btn_addAypen);
            this.panel_aypen.Controls.Add(this.lb_pAypen);
            this.panel_aypen.Controls.Add(this.lb_aypen);
            this.panel_aypen.Controls.Add(this.pb_aypen);
            this.panel_aypen.Location = new System.Drawing.Point(418, 1228);
            this.panel_aypen.Name = "panel_aypen";
            this.panel_aypen.Size = new System.Drawing.Size(170, 228);
            this.panel_aypen.TabIndex = 57;
            // 
            // btn_minAypen
            // 
            this.btn_minAypen.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_minAypen.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_minAypen.Location = new System.Drawing.Point(87, 186);
            this.btn_minAypen.Name = "btn_minAypen";
            this.btn_minAypen.Size = new System.Drawing.Size(40, 41);
            this.btn_minAypen.TabIndex = 25;
            this.btn_minAypen.Text = "-";
            this.btn_minAypen.UseVisualStyleBackColor = false;
            this.btn_minAypen.Click += new System.EventHandler(this.btn_minAypen_Click);
            // 
            // btn_addAypen
            // 
            this.btn_addAypen.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_addAypen.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_addAypen.Location = new System.Drawing.Point(46, 186);
            this.btn_addAypen.Name = "btn_addAypen";
            this.btn_addAypen.Size = new System.Drawing.Size(40, 41);
            this.btn_addAypen.TabIndex = 24;
            this.btn_addAypen.Text = "+";
            this.btn_addAypen.UseVisualStyleBackColor = false;
            this.btn_addAypen.Click += new System.EventHandler(this.btn_addAypen_Click);
            // 
            // lb_pAypen
            // 
            this.lb_pAypen.AutoSize = true;
            this.lb_pAypen.Location = new System.Drawing.Point(14, 159);
            this.lb_pAypen.Name = "lb_pAypen";
            this.lb_pAypen.Size = new System.Drawing.Size(141, 25);
            this.lb_pAypen.TabIndex = 23;
            this.lb_pAypen.Text = "Rp 35.000,00";
            // 
            // lb_aypen
            // 
            this.lb_aypen.AutoSize = true;
            this.lb_aypen.Location = new System.Drawing.Point(18, 130);
            this.lb_aypen.Name = "lb_aypen";
            this.lb_aypen.Size = new System.Drawing.Size(139, 25);
            this.lb_aypen.TabIndex = 22;
            this.lb_aypen.Text = "Ayam Penyet";
            // 
            // panel_bakwan
            // 
            this.panel_bakwan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel_bakwan.Controls.Add(this.btn_minBakwan);
            this.panel_bakwan.Controls.Add(this.btn_addBakwan);
            this.panel_bakwan.Controls.Add(this.lb_pBakwan);
            this.panel_bakwan.Controls.Add(this.lb_bakwan);
            this.panel_bakwan.Controls.Add(this.pb_bawkan);
            this.panel_bakwan.Location = new System.Drawing.Point(232, 1467);
            this.panel_bakwan.Name = "panel_bakwan";
            this.panel_bakwan.Size = new System.Drawing.Size(170, 228);
            this.panel_bakwan.TabIndex = 59;
            // 
            // btn_minBakwan
            // 
            this.btn_minBakwan.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_minBakwan.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_minBakwan.Location = new System.Drawing.Point(87, 186);
            this.btn_minBakwan.Name = "btn_minBakwan";
            this.btn_minBakwan.Size = new System.Drawing.Size(40, 41);
            this.btn_minBakwan.TabIndex = 25;
            this.btn_minBakwan.Text = "-";
            this.btn_minBakwan.UseVisualStyleBackColor = false;
            this.btn_minBakwan.Click += new System.EventHandler(this.btn_minBakwan_Click);
            // 
            // btn_addBakwan
            // 
            this.btn_addBakwan.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_addBakwan.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_addBakwan.Location = new System.Drawing.Point(46, 186);
            this.btn_addBakwan.Name = "btn_addBakwan";
            this.btn_addBakwan.Size = new System.Drawing.Size(40, 41);
            this.btn_addBakwan.TabIndex = 24;
            this.btn_addBakwan.Text = "+";
            this.btn_addBakwan.UseVisualStyleBackColor = false;
            this.btn_addBakwan.Click += new System.EventHandler(this.btn_addBakwan_Click);
            // 
            // lb_pBakwan
            // 
            this.lb_pBakwan.AutoSize = true;
            this.lb_pBakwan.Location = new System.Drawing.Point(14, 159);
            this.lb_pBakwan.Name = "lb_pBakwan";
            this.lb_pBakwan.Size = new System.Drawing.Size(141, 25);
            this.lb_pBakwan.TabIndex = 23;
            this.lb_pBakwan.Text = "Rp 30.000,00";
            // 
            // lb_bakwan
            // 
            this.lb_bakwan.AutoSize = true;
            this.lb_bakwan.Location = new System.Drawing.Point(4, 130);
            this.lb_bakwan.Name = "lb_bakwan";
            this.lb_bakwan.Size = new System.Drawing.Size(161, 25);
            this.lb_bakwan.TabIndex = 22;
            this.lb_bakwan.Text = "Bakwan Penyet";
            // 
            // panel_empal
            // 
            this.panel_empal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel_empal.Controls.Add(this.btn_minEmpal);
            this.panel_empal.Controls.Add(this.btn_addEmpal);
            this.panel_empal.Controls.Add(this.lb_pEmpal);
            this.panel_empal.Controls.Add(this.lb_empal);
            this.panel_empal.Controls.Add(this.pb_empal);
            this.panel_empal.Location = new System.Drawing.Point(48, 1467);
            this.panel_empal.Name = "panel_empal";
            this.panel_empal.Size = new System.Drawing.Size(170, 228);
            this.panel_empal.TabIndex = 58;
            // 
            // btn_minEmpal
            // 
            this.btn_minEmpal.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_minEmpal.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_minEmpal.Location = new System.Drawing.Point(87, 186);
            this.btn_minEmpal.Name = "btn_minEmpal";
            this.btn_minEmpal.Size = new System.Drawing.Size(40, 41);
            this.btn_minEmpal.TabIndex = 25;
            this.btn_minEmpal.Text = "-";
            this.btn_minEmpal.UseVisualStyleBackColor = false;
            this.btn_minEmpal.Click += new System.EventHandler(this.btn_minEmpal_Click);
            // 
            // btn_addEmpal
            // 
            this.btn_addEmpal.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_addEmpal.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_addEmpal.Location = new System.Drawing.Point(46, 186);
            this.btn_addEmpal.Name = "btn_addEmpal";
            this.btn_addEmpal.Size = new System.Drawing.Size(40, 41);
            this.btn_addEmpal.TabIndex = 24;
            this.btn_addEmpal.Text = "+";
            this.btn_addEmpal.UseVisualStyleBackColor = false;
            this.btn_addEmpal.Click += new System.EventHandler(this.btn_addEmpal_Click);
            // 
            // lb_pEmpal
            // 
            this.lb_pEmpal.AutoSize = true;
            this.lb_pEmpal.Location = new System.Drawing.Point(14, 159);
            this.lb_pEmpal.Name = "lb_pEmpal";
            this.lb_pEmpal.Size = new System.Drawing.Size(141, 25);
            this.lb_pEmpal.TabIndex = 23;
            this.lb_pEmpal.Text = "Rp 35.000,00";
            // 
            // lb_empal
            // 
            this.lb_empal.AutoSize = true;
            this.lb_empal.Location = new System.Drawing.Point(12, 130);
            this.lb_empal.Name = "lb_empal";
            this.lb_empal.Size = new System.Drawing.Size(145, 25);
            this.lb_empal.TabIndex = 22;
            this.lb_empal.Text = "Empal Penyet";
            // 
            // panel_aygor
            // 
            this.panel_aygor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel_aygor.Controls.Add(this.btn_minAygor);
            this.panel_aygor.Controls.Add(this.btn_addAygor);
            this.panel_aygor.Controls.Add(this.lb_pAygor);
            this.panel_aygor.Controls.Add(this.lb_aygor);
            this.panel_aygor.Controls.Add(this.pb_aygor);
            this.panel_aygor.Location = new System.Drawing.Point(234, 1228);
            this.panel_aygor.Name = "panel_aygor";
            this.panel_aygor.Size = new System.Drawing.Size(170, 228);
            this.panel_aygor.TabIndex = 56;
            // 
            // btn_minAygor
            // 
            this.btn_minAygor.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_minAygor.Location = new System.Drawing.Point(87, 186);
            this.btn_minAygor.Name = "btn_minAygor";
            this.btn_minAygor.Size = new System.Drawing.Size(40, 41);
            this.btn_minAygor.TabIndex = 25;
            this.btn_minAygor.Text = "-";
            this.btn_minAygor.UseVisualStyleBackColor = false;
            this.btn_minAygor.Click += new System.EventHandler(this.btn_minAygor_Click);
            // 
            // btn_addAygor
            // 
            this.btn_addAygor.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_addAygor.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_addAygor.Location = new System.Drawing.Point(46, 186);
            this.btn_addAygor.Name = "btn_addAygor";
            this.btn_addAygor.Size = new System.Drawing.Size(40, 41);
            this.btn_addAygor.TabIndex = 24;
            this.btn_addAygor.Text = "+";
            this.btn_addAygor.UseVisualStyleBackColor = false;
            this.btn_addAygor.Click += new System.EventHandler(this.btn_addAygor_Click);
            // 
            // lb_pAygor
            // 
            this.lb_pAygor.AutoSize = true;
            this.lb_pAygor.Location = new System.Drawing.Point(14, 159);
            this.lb_pAygor.Name = "lb_pAygor";
            this.lb_pAygor.Size = new System.Drawing.Size(141, 25);
            this.lb_pAygor.TabIndex = 23;
            this.lb_pAygor.Text = "Rp 30.000,00";
            // 
            // lb_aygor
            // 
            this.lb_aygor.AutoSize = true;
            this.lb_aygor.Location = new System.Drawing.Point(14, 130);
            this.lb_aygor.Name = "lb_aygor";
            this.lb_aygor.Size = new System.Drawing.Size(143, 25);
            this.lb_aygor.TabIndex = 22;
            this.lb_aygor.Text = "Ayam Goreng";
            // 
            // panel_nascam
            // 
            this.panel_nascam.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel_nascam.Controls.Add(this.btn_minNascam);
            this.panel_nascam.Controls.Add(this.btn_addNascam);
            this.panel_nascam.Controls.Add(this.lb_pNascam);
            this.panel_nascam.Controls.Add(this.lb_nascam);
            this.panel_nascam.Controls.Add(this.pb_nascam);
            this.panel_nascam.Location = new System.Drawing.Point(50, 1228);
            this.panel_nascam.Name = "panel_nascam";
            this.panel_nascam.Size = new System.Drawing.Size(170, 228);
            this.panel_nascam.TabIndex = 55;
            // 
            // btn_minNascam
            // 
            this.btn_minNascam.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_minNascam.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_minNascam.Location = new System.Drawing.Point(87, 186);
            this.btn_minNascam.Name = "btn_minNascam";
            this.btn_minNascam.Size = new System.Drawing.Size(40, 41);
            this.btn_minNascam.TabIndex = 25;
            this.btn_minNascam.Text = "-";
            this.btn_minNascam.UseVisualStyleBackColor = false;
            this.btn_minNascam.Click += new System.EventHandler(this.btn_minNascam_Click);
            // 
            // btn_addNascam
            // 
            this.btn_addNascam.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_addNascam.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_addNascam.Location = new System.Drawing.Point(46, 186);
            this.btn_addNascam.Name = "btn_addNascam";
            this.btn_addNascam.Size = new System.Drawing.Size(40, 41);
            this.btn_addNascam.TabIndex = 24;
            this.btn_addNascam.Text = "+";
            this.btn_addNascam.UseVisualStyleBackColor = false;
            this.btn_addNascam.Click += new System.EventHandler(this.btn_addNascam_Click);
            // 
            // lb_pNascam
            // 
            this.lb_pNascam.AutoSize = true;
            this.lb_pNascam.Location = new System.Drawing.Point(14, 159);
            this.lb_pNascam.Name = "lb_pNascam";
            this.lb_pNascam.Size = new System.Drawing.Size(141, 25);
            this.lb_pNascam.TabIndex = 23;
            this.lb_pNascam.Text = "Rp 40.000,00";
            // 
            // lb_nascam
            // 
            this.lb_nascam.AutoSize = true;
            this.lb_nascam.Location = new System.Drawing.Point(16, 130);
            this.lb_nascam.Name = "lb_nascam";
            this.lb_nascam.Size = new System.Drawing.Size(136, 25);
            this.lb_nascam.TabIndex = 22;
            this.lb_nascam.Text = "Nasi Campur";
            // 
            // stat_date
            // 
            this.stat_date.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.stat_date.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dateStatus});
            this.stat_date.Location = new System.Drawing.Point(0, 1937);
            this.stat_date.Name = "stat_date";
            this.stat_date.Padding = new System.Windows.Forms.Padding(2, 0, 18, 0);
            this.stat_date.Size = new System.Drawing.Size(1324, 42);
            this.stat_date.TabIndex = 62;
            this.stat_date.Text = "statusStrip1";
            // 
            // dateStatus
            // 
            this.dateStatus.Name = "dateStatus";
            this.dateStatus.Size = new System.Drawing.Size(237, 32);
            this.dateStatus.Text = "toolStripStatusLabel1";
            // 
            // timer_kasir
            // 
            this.timer_kasir.Enabled = true;
            this.timer_kasir.Interval = 1000;
            this.timer_kasir.Tick += new System.EventHandler(this.timer_kasir_Tick);
            // 
            // pb_nasi
            // 
            this.pb_nasi.Image = global::ALP.Properties.Resources.Nasi_Putih;
            this.pb_nasi.Location = new System.Drawing.Point(9, 6);
            this.pb_nasi.Name = "pb_nasi";
            this.pb_nasi.Size = new System.Drawing.Size(150, 120);
            this.pb_nasi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_nasi.TabIndex = 21;
            this.pb_nasi.TabStop = false;
            // 
            // pb_bakso
            // 
            this.pb_bakso.Image = global::ALP.Properties.Resources.Bakso_Sapi;
            this.pb_bakso.Location = new System.Drawing.Point(9, 6);
            this.pb_bakso.Name = "pb_bakso";
            this.pb_bakso.Size = new System.Drawing.Size(150, 120);
            this.pb_bakso.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_bakso.TabIndex = 21;
            this.pb_bakso.TabStop = false;
            // 
            // pb_aypen
            // 
            this.pb_aypen.Image = global::ALP.Properties.Resources.Ayam_Penyet;
            this.pb_aypen.Location = new System.Drawing.Point(9, 6);
            this.pb_aypen.Name = "pb_aypen";
            this.pb_aypen.Size = new System.Drawing.Size(150, 120);
            this.pb_aypen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_aypen.TabIndex = 21;
            this.pb_aypen.TabStop = false;
            // 
            // pb_bawkan
            // 
            this.pb_bawkan.Image = global::ALP.Properties.Resources.Bakwan_Penyet;
            this.pb_bawkan.Location = new System.Drawing.Point(9, 6);
            this.pb_bawkan.Name = "pb_bawkan";
            this.pb_bawkan.Size = new System.Drawing.Size(150, 120);
            this.pb_bawkan.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_bawkan.TabIndex = 21;
            this.pb_bawkan.TabStop = false;
            // 
            // pb_empal
            // 
            this.pb_empal.Image = global::ALP.Properties.Resources.Empal_Penyet;
            this.pb_empal.Location = new System.Drawing.Point(9, 6);
            this.pb_empal.Name = "pb_empal";
            this.pb_empal.Size = new System.Drawing.Size(150, 120);
            this.pb_empal.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_empal.TabIndex = 21;
            this.pb_empal.TabStop = false;
            // 
            // pb_aygor
            // 
            this.pb_aygor.Image = global::ALP.Properties.Resources.Ayam_Goreng;
            this.pb_aygor.Location = new System.Drawing.Point(9, 6);
            this.pb_aygor.Name = "pb_aygor";
            this.pb_aygor.Size = new System.Drawing.Size(150, 120);
            this.pb_aygor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_aygor.TabIndex = 21;
            this.pb_aygor.TabStop = false;
            // 
            // pb_nascam
            // 
            this.pb_nascam.Image = global::ALP.Properties.Resources.Nasi_Campur;
            this.pb_nascam.Location = new System.Drawing.Point(9, 6);
            this.pb_nascam.Name = "pb_nascam";
            this.pb_nascam.Size = new System.Drawing.Size(150, 120);
            this.pb_nascam.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_nascam.TabIndex = 21;
            this.pb_nascam.TabStop = false;
            // 
            // pb_sate
            // 
            this.pb_sate.Image = global::ALP.Properties.Resources.Sate_Ayam;
            this.pb_sate.Location = new System.Drawing.Point(9, 6);
            this.pb_sate.Name = "pb_sate";
            this.pb_sate.Size = new System.Drawing.Size(150, 120);
            this.pb_sate.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_sate.TabIndex = 21;
            this.pb_sate.TabStop = false;
            // 
            // pb_soto
            // 
            this.pb_soto.Image = global::ALP.Properties.Resources.Soto_Mie;
            this.pb_soto.Location = new System.Drawing.Point(9, 6);
            this.pb_soto.Name = "pb_soto";
            this.pb_soto.Size = new System.Drawing.Size(150, 120);
            this.pb_soto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_soto.TabIndex = 21;
            this.pb_soto.TabStop = false;
            // 
            // pb_batagor
            // 
            this.pb_batagor.Image = global::ALP.Properties.Resources.Batagor;
            this.pb_batagor.Location = new System.Drawing.Point(9, 6);
            this.pb_batagor.Name = "pb_batagor";
            this.pb_batagor.Size = new System.Drawing.Size(150, 120);
            this.pb_batagor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_batagor.TabIndex = 21;
            this.pb_batagor.TabStop = false;
            // 
            // pb_sopbun
            // 
            this.pb_sopbun.Image = global::ALP.Properties.Resources.Sop_Buntut;
            this.pb_sopbun.Location = new System.Drawing.Point(9, 6);
            this.pb_sopbun.Name = "pb_sopbun";
            this.pb_sopbun.Size = new System.Drawing.Size(150, 120);
            this.pb_sopbun.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_sopbun.TabIndex = 21;
            this.pb_sopbun.TabStop = false;
            // 
            // pb_pecel
            // 
            this.pb_pecel.Image = global::ALP.Properties.Resources.Nasi_Pecel;
            this.pb_pecel.Location = new System.Drawing.Point(9, 6);
            this.pb_pecel.Name = "pb_pecel";
            this.pb_pecel.Size = new System.Drawing.Size(150, 120);
            this.pb_pecel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_pecel.TabIndex = 21;
            this.pb_pecel.TabStop = false;
            // 
            // pb_miegor
            // 
            this.pb_miegor.Image = global::ALP.Properties.Resources.Mie_Goreng;
            this.pb_miegor.Location = new System.Drawing.Point(9, 6);
            this.pb_miegor.Name = "pb_miegor";
            this.pb_miegor.Size = new System.Drawing.Size(150, 120);
            this.pb_miegor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_miegor.TabIndex = 21;
            this.pb_miegor.TabStop = false;
            // 
            // pb_rawon
            // 
            this.pb_rawon.Image = global::ALP.Properties.Resources.Rawon;
            this.pb_rawon.Location = new System.Drawing.Point(9, 6);
            this.pb_rawon.Name = "pb_rawon";
            this.pb_rawon.Size = new System.Drawing.Size(150, 120);
            this.pb_rawon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_rawon.TabIndex = 21;
            this.pb_rawon.TabStop = false;
            // 
            // pb_gadogado
            // 
            this.pb_gadogado.Image = global::ALP.Properties.Resources.Gado_gado;
            this.pb_gadogado.Location = new System.Drawing.Point(9, 6);
            this.pb_gadogado.Name = "pb_gadogado";
            this.pb_gadogado.Size = new System.Drawing.Size(150, 120);
            this.pb_gadogado.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_gadogado.TabIndex = 21;
            this.pb_gadogado.TabStop = false;
            // 
            // pb_nasgor
            // 
            this.pb_nasgor.Image = global::ALP.Properties.Resources.Nasi_Goreng;
            this.pb_nasgor.Location = new System.Drawing.Point(9, 6);
            this.pb_nasgor.Name = "pb_nasgor";
            this.pb_nasgor.Size = new System.Drawing.Size(150, 120);
            this.pb_nasgor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_nasgor.TabIndex = 21;
            this.pb_nasgor.TabStop = false;
            // 
            // FormFood
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.Snow;
            this.ClientSize = new System.Drawing.Size(1358, 1050);
            this.Controls.Add(this.stat_date);
            this.Controls.Add(this.panel_nasi);
            this.Controls.Add(this.panel_bakso);
            this.Controls.Add(this.panel_aypen);
            this.Controls.Add(this.panel_bakwan);
            this.Controls.Add(this.panel_empal);
            this.Controls.Add(this.panel_aygor);
            this.Controls.Add(this.panel_nascam);
            this.Controls.Add(this.panel_sate);
            this.Controls.Add(this.panel_soto);
            this.Controls.Add(this.panel_batagor);
            this.Controls.Add(this.panel_sopbun);
            this.Controls.Add(this.panel_pecel);
            this.Controls.Add(this.panel_miegor);
            this.Controls.Add(this.panel_rawon);
            this.Controls.Add(this.panel_gadogado);
            this.Controls.Add(this.panel_nasgor);
            this.Controls.Add(this.lb_staffID);
            this.Controls.Add(this.lb_tableNo);
            this.Controls.Add(this.btn_Next);
            this.Controls.Add(this.tb_totalP);
            this.Controls.Add(this.tb_totalQ);
            this.Controls.Add(this.lb_totalP);
            this.Controls.Add(this.lb_totalQ);
            this.Controls.Add(this.dgv_pesanan);
            this.Controls.Add(this.lb_daftarP);
            this.Controls.Add(this.lb_noTable);
            this.Controls.Add(this.lb_ID);
            this.Name = "FormFood";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "FormFood";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormFood_Load);
            this.panel_sate.ResumeLayout(false);
            this.panel_sate.PerformLayout();
            this.panel_soto.ResumeLayout(false);
            this.panel_soto.PerformLayout();
            this.panel_batagor.ResumeLayout(false);
            this.panel_batagor.PerformLayout();
            this.panel_sopbun.ResumeLayout(false);
            this.panel_sopbun.PerformLayout();
            this.panel_pecel.ResumeLayout(false);
            this.panel_pecel.PerformLayout();
            this.panel_miegor.ResumeLayout(false);
            this.panel_miegor.PerformLayout();
            this.panel_rawon.ResumeLayout(false);
            this.panel_rawon.PerformLayout();
            this.panel_gadogado.ResumeLayout(false);
            this.panel_gadogado.PerformLayout();
            this.panel_nasgor.ResumeLayout(false);
            this.panel_nasgor.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_pesanan)).EndInit();
            this.panel_nasi.ResumeLayout(false);
            this.panel_nasi.PerformLayout();
            this.panel_bakso.ResumeLayout(false);
            this.panel_bakso.PerformLayout();
            this.panel_aypen.ResumeLayout(false);
            this.panel_aypen.PerformLayout();
            this.panel_bakwan.ResumeLayout(false);
            this.panel_bakwan.PerformLayout();
            this.panel_empal.ResumeLayout(false);
            this.panel_empal.PerformLayout();
            this.panel_aygor.ResumeLayout(false);
            this.panel_aygor.PerformLayout();
            this.panel_nascam.ResumeLayout(false);
            this.panel_nascam.PerformLayout();
            this.stat_date.ResumeLayout(false);
            this.stat_date.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_nasi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_bakso)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_aypen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_bawkan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_empal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_aygor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_nascam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_sate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_soto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_batagor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_sopbun)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_pecel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_miegor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_rawon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_gadogado)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_nasgor)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel_sate;
        private System.Windows.Forms.Button btn_minSate;
        private System.Windows.Forms.Button btn_addSate;
        private System.Windows.Forms.Label lb_pSate;
        private System.Windows.Forms.Label lb_sate;
        private System.Windows.Forms.PictureBox pb_sate;
        private System.Windows.Forms.Panel panel_soto;
        private System.Windows.Forms.Button btn_minSoto;
        private System.Windows.Forms.Button btn_addSoto;
        private System.Windows.Forms.Label lb_pSoto;
        private System.Windows.Forms.Label lb_soto;
        private System.Windows.Forms.PictureBox pb_soto;
        private System.Windows.Forms.Panel panel_batagor;
        private System.Windows.Forms.Button btn_minBatagor;
        private System.Windows.Forms.Button btn_addBatagor;
        private System.Windows.Forms.Label lb_pBatagor;
        private System.Windows.Forms.Label lb_batagor;
        private System.Windows.Forms.PictureBox pb_batagor;
        private System.Windows.Forms.Panel panel_sopbun;
        private System.Windows.Forms.Button btn_minSopbun;
        private System.Windows.Forms.Button btn_addSopbun;
        private System.Windows.Forms.Label lb_pSopbun;
        private System.Windows.Forms.Label lb_sopbun;
        private System.Windows.Forms.PictureBox pb_sopbun;
        private System.Windows.Forms.Panel panel_pecel;
        private System.Windows.Forms.Button btn_minPecel;
        private System.Windows.Forms.Button btn_addPecel;
        private System.Windows.Forms.Label lb_pPecel;
        private System.Windows.Forms.Label lb_pecel;
        private System.Windows.Forms.PictureBox pb_pecel;
        private System.Windows.Forms.Panel panel_miegor;
        private System.Windows.Forms.Button btn_minMiegor;
        private System.Windows.Forms.Button btn_addMiegor;
        private System.Windows.Forms.Label lb_pMiegor;
        private System.Windows.Forms.Label lb_miegor;
        private System.Windows.Forms.PictureBox pb_miegor;
        private System.Windows.Forms.Panel panel_rawon;
        private System.Windows.Forms.Button btn_minRawon;
        private System.Windows.Forms.Button btn_addRawon;
        private System.Windows.Forms.Label lb_pRawon;
        private System.Windows.Forms.Label lb_rawon;
        private System.Windows.Forms.PictureBox pb_rawon;
        private System.Windows.Forms.Panel panel_gadogado;
        private System.Windows.Forms.Button btn_minGadogado;
        private System.Windows.Forms.Button btn_addGadogado;
        private System.Windows.Forms.Label lb_pGadogado;
        private System.Windows.Forms.Label lb_gadogado;
        private System.Windows.Forms.PictureBox pb_gadogado;
        private System.Windows.Forms.Panel panel_nasgor;
        private System.Windows.Forms.Button btn_minNasgor;
        private System.Windows.Forms.Button btn_addNasgor;
        private System.Windows.Forms.Label lb_pNasgor;
        private System.Windows.Forms.Label lb_nasgor;
        private System.Windows.Forms.PictureBox pb_nasgor;
        private System.Windows.Forms.Label lb_staffID;
        private System.Windows.Forms.Label lb_tableNo;
        private System.Windows.Forms.Button btn_Next;
        private System.Windows.Forms.TextBox tb_totalP;
        private System.Windows.Forms.TextBox tb_totalQ;
        private System.Windows.Forms.Label lb_totalP;
        private System.Windows.Forms.Label lb_totalQ;
        private System.Windows.Forms.DataGridView dgv_pesanan;
        private System.Windows.Forms.Label lb_daftarP;
        private System.Windows.Forms.Label lb_noTable;
        private System.Windows.Forms.Label lb_ID;
        private System.Windows.Forms.Panel panel_nasi;
        private System.Windows.Forms.Button btn_minNasi;
        private System.Windows.Forms.Button btn_addNasi;
        private System.Windows.Forms.Label lb_pNasi;
        private System.Windows.Forms.Label lb_nasi;
        private System.Windows.Forms.PictureBox pb_nasi;
        private System.Windows.Forms.Panel panel_bakso;
        private System.Windows.Forms.Button btn_minBakso;
        private System.Windows.Forms.Button btn_addBakso;
        private System.Windows.Forms.Label lb_pBakso;
        private System.Windows.Forms.Label lb_bakso;
        private System.Windows.Forms.PictureBox pb_bakso;
        private System.Windows.Forms.Panel panel_aypen;
        private System.Windows.Forms.Button btn_minAypen;
        private System.Windows.Forms.Button btn_addAypen;
        private System.Windows.Forms.Label lb_pAypen;
        private System.Windows.Forms.Label lb_aypen;
        private System.Windows.Forms.PictureBox pb_aypen;
        private System.Windows.Forms.Panel panel_bakwan;
        private System.Windows.Forms.Button btn_minBakwan;
        private System.Windows.Forms.Button btn_addBakwan;
        private System.Windows.Forms.Label lb_pBakwan;
        private System.Windows.Forms.Label lb_bakwan;
        private System.Windows.Forms.PictureBox pb_bawkan;
        private System.Windows.Forms.Panel panel_empal;
        private System.Windows.Forms.Button btn_minEmpal;
        private System.Windows.Forms.Button btn_addEmpal;
        private System.Windows.Forms.Label lb_pEmpal;
        private System.Windows.Forms.Label lb_empal;
        private System.Windows.Forms.PictureBox pb_empal;
        private System.Windows.Forms.Panel panel_aygor;
        private System.Windows.Forms.Button btn_minAygor;
        private System.Windows.Forms.Button btn_addAygor;
        private System.Windows.Forms.Label lb_pAygor;
        private System.Windows.Forms.Label lb_aygor;
        private System.Windows.Forms.PictureBox pb_aygor;
        private System.Windows.Forms.Panel panel_nascam;
        private System.Windows.Forms.Button btn_minNascam;
        private System.Windows.Forms.Button btn_addNascam;
        private System.Windows.Forms.Label lb_pNascam;
        private System.Windows.Forms.Label lb_nascam;
        private System.Windows.Forms.PictureBox pb_nascam;
        private System.Windows.Forms.StatusStrip stat_date;
        private System.Windows.Forms.ToolStripStatusLabel dateStatus;
        private System.Windows.Forms.Timer timer_kasir;
    }
}