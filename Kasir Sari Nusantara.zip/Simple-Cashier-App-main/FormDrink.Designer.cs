﻿namespace ALP
{
    partial class FormDrink
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lb_staffID = new System.Windows.Forms.Label();
            this.lb_tableNo = new System.Windows.Forms.Label();
            this.btn_Next = new System.Windows.Forms.Button();
            this.tb_totalP = new System.Windows.Forms.TextBox();
            this.tb_totalQ = new System.Windows.Forms.TextBox();
            this.lb_totalP = new System.Windows.Forms.Label();
            this.lb_totalQ = new System.Windows.Forms.Label();
            this.dgv_pesanan = new System.Windows.Forms.DataGridView();
            this.lb_daftarP = new System.Windows.Forms.Label();
            this.lb_noTable = new System.Windows.Forms.Label();
            this.lb_ID = new System.Windows.Forms.Label();
            this.panel_tehtawar = new System.Windows.Forms.Panel();
            this.btn_minTehtawar = new System.Windows.Forms.Button();
            this.btn_addTehtawar = new System.Windows.Forms.Button();
            this.lb_pTehtawar = new System.Windows.Forms.Label();
            this.lb_tehtawar = new System.Windows.Forms.Label();
            this.panel_tehmanis = new System.Windows.Forms.Panel();
            this.btn_minTehmanis = new System.Windows.Forms.Button();
            this.btn_addTehmanis = new System.Windows.Forms.Button();
            this.lb_pTehmanis = new System.Windows.Forms.Label();
            this.lb_tehmanis = new System.Windows.Forms.Label();
            this.panel_air = new System.Windows.Forms.Panel();
            this.btn_minAir = new System.Windows.Forms.Button();
            this.btn_addAir = new System.Windows.Forms.Button();
            this.lb_pAir = new System.Windows.Forms.Label();
            this.lb_air = new System.Windows.Forms.Label();
            this.panel_cendol = new System.Windows.Forms.Panel();
            this.btn_minCendol = new System.Windows.Forms.Button();
            this.btn_addCendol = new System.Windows.Forms.Button();
            this.lb_pCendol = new System.Windows.Forms.Label();
            this.lb_cendol = new System.Windows.Forms.Label();
            this.panel_jernip = new System.Windows.Forms.Panel();
            this.btn_minJernip = new System.Windows.Forms.Button();
            this.btn_addJernip = new System.Windows.Forms.Button();
            this.lb_pJernip = new System.Windows.Forms.Label();
            this.lb_jernip = new System.Windows.Forms.Label();
            this.panel_jeruk = new System.Windows.Forms.Panel();
            this.btn_minJeruk = new System.Windows.Forms.Button();
            this.btn_addJeruk = new System.Windows.Forms.Button();
            this.lb_pJeruk = new System.Windows.Forms.Label();
            this.lb_jeruk = new System.Windows.Forms.Label();
            this.panel_sirsak = new System.Windows.Forms.Panel();
            this.btn_minSirsak = new System.Windows.Forms.Button();
            this.btn_addSirsak = new System.Windows.Forms.Button();
            this.lb_pSirsak = new System.Windows.Forms.Label();
            this.lb_sirsak = new System.Windows.Forms.Label();
            this.panel_tehtarik = new System.Windows.Forms.Panel();
            this.btn_minTehTarik = new System.Windows.Forms.Button();
            this.btn_addTehtarik = new System.Windows.Forms.Button();
            this.lb_pTehtarik = new System.Windows.Forms.Label();
            this.lb_tehtarik = new System.Windows.Forms.Label();
            this.panel_alpukat = new System.Windows.Forms.Panel();
            this.btn_minAlpukat = new System.Windows.Forms.Button();
            this.btn_addAlpukat = new System.Windows.Forms.Button();
            this.lb_pAlpukat = new System.Windows.Forms.Label();
            this.lb_alpukat = new System.Windows.Forms.Label();
            this.panel_jahe = new System.Windows.Forms.Panel();
            this.btn_minJahe = new System.Windows.Forms.Button();
            this.btn_addJahe = new System.Windows.Forms.Button();
            this.lb_pJahe = new System.Windows.Forms.Label();
            this.lb_jahe = new System.Windows.Forms.Label();
            this.panel_buah = new System.Windows.Forms.Panel();
            this.btn_minBuah = new System.Windows.Forms.Button();
            this.btn_addBuah = new System.Windows.Forms.Button();
            this.lb_pBuah = new System.Windows.Forms.Label();
            this.lb_buah = new System.Windows.Forms.Label();
            this.panel_degan = new System.Windows.Forms.Panel();
            this.btn_minDegan = new System.Windows.Forms.Button();
            this.btn_addDegan = new System.Windows.Forms.Button();
            this.lb_pDegan = new System.Windows.Forms.Label();
            this.lb_degan = new System.Windows.Forms.Label();
            this.panel_naga = new System.Windows.Forms.Panel();
            this.btn_minNaga = new System.Windows.Forms.Button();
            this.btn_addNaga = new System.Windows.Forms.Button();
            this.lb_pNaga = new System.Windows.Forms.Label();
            this.lb_naga = new System.Windows.Forms.Label();
            this.panel_mangga = new System.Windows.Forms.Panel();
            this.btn_minMangga = new System.Windows.Forms.Button();
            this.btn_addMangga = new System.Windows.Forms.Button();
            this.lb_pMangga = new System.Windows.Forms.Label();
            this.lb_mangga = new System.Windows.Forms.Label();
            this.stat_date = new System.Windows.Forms.StatusStrip();
            this.dateStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.timer_kasir = new System.Windows.Forms.Timer(this.components);
            this.pb_naga = new System.Windows.Forms.PictureBox();
            this.pb_sirsak = new System.Windows.Forms.PictureBox();
            this.pb_mangga = new System.Windows.Forms.PictureBox();
            this.pb_cendol = new System.Windows.Forms.PictureBox();
            this.pb_tektarik = new System.Windows.Forms.PictureBox();
            this.pb_tehtawar = new System.Windows.Forms.PictureBox();
            this.pb_alpukat = new System.Windows.Forms.PictureBox();
            this.pb_jernip = new System.Windows.Forms.PictureBox();
            this.pb_jahe = new System.Windows.Forms.PictureBox();
            this.pb_tehmanis = new System.Windows.Forms.PictureBox();
            this.pb_buah = new System.Windows.Forms.PictureBox();
            this.pb_jeruk = new System.Windows.Forms.PictureBox();
            this.pb_degan = new System.Windows.Forms.PictureBox();
            this.pb_air = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_pesanan)).BeginInit();
            this.panel_tehtawar.SuspendLayout();
            this.panel_tehmanis.SuspendLayout();
            this.panel_air.SuspendLayout();
            this.panel_cendol.SuspendLayout();
            this.panel_jernip.SuspendLayout();
            this.panel_jeruk.SuspendLayout();
            this.panel_sirsak.SuspendLayout();
            this.panel_tehtarik.SuspendLayout();
            this.panel_alpukat.SuspendLayout();
            this.panel_jahe.SuspendLayout();
            this.panel_buah.SuspendLayout();
            this.panel_degan.SuspendLayout();
            this.panel_naga.SuspendLayout();
            this.panel_mangga.SuspendLayout();
            this.stat_date.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_naga)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_sirsak)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_mangga)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_cendol)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tektarik)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tehtawar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_alpukat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_jernip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_jahe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tehmanis)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_buah)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_jeruk)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_degan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_air)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_staffID
            // 
            this.lb_staffID.AutoSize = true;
            this.lb_staffID.Location = new System.Drawing.Point(1023, 41);
            this.lb_staffID.Name = "lb_staffID";
            this.lb_staffID.Size = new System.Drawing.Size(19, 25);
            this.lb_staffID.TabIndex = 56;
            this.lb_staffID.Text = "-";
            // 
            // lb_tableNo
            // 
            this.lb_tableNo.AutoSize = true;
            this.lb_tableNo.Location = new System.Drawing.Point(1079, 88);
            this.lb_tableNo.Name = "lb_tableNo";
            this.lb_tableNo.Size = new System.Drawing.Size(19, 25);
            this.lb_tableNo.TabIndex = 55;
            this.lb_tableNo.Text = "-";
            // 
            // btn_Next
            // 
            this.btn_Next.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btn_Next.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Next.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Next.Location = new System.Drawing.Point(789, 705);
            this.btn_Next.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Next.Name = "btn_Next";
            this.btn_Next.Size = new System.Drawing.Size(116, 41);
            this.btn_Next.TabIndex = 54;
            this.btn_Next.Text = "Next";
            this.btn_Next.UseVisualStyleBackColor = false;
            this.btn_Next.Click += new System.EventHandler(this.btn_Next_Click);
            // 
            // tb_totalP
            // 
            this.tb_totalP.Enabled = false;
            this.tb_totalP.Location = new System.Drawing.Point(789, 656);
            this.tb_totalP.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tb_totalP.Name = "tb_totalP";
            this.tb_totalP.Size = new System.Drawing.Size(188, 31);
            this.tb_totalP.TabIndex = 53;
            // 
            // tb_totalQ
            // 
            this.tb_totalQ.Enabled = false;
            this.tb_totalQ.Location = new System.Drawing.Point(789, 616);
            this.tb_totalQ.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tb_totalQ.Name = "tb_totalQ";
            this.tb_totalQ.Size = new System.Drawing.Size(188, 31);
            this.tb_totalQ.TabIndex = 52;
            // 
            // lb_totalP
            // 
            this.lb_totalP.AutoSize = true;
            this.lb_totalP.Location = new System.Drawing.Point(629, 656);
            this.lb_totalP.Name = "lb_totalP";
            this.lb_totalP.Size = new System.Drawing.Size(121, 25);
            this.lb_totalP.TabIndex = 51;
            this.lb_totalP.Text = "Total Price:";
            // 
            // lb_totalQ
            // 
            this.lb_totalQ.AutoSize = true;
            this.lb_totalQ.Location = new System.Drawing.Point(629, 616);
            this.lb_totalQ.Name = "lb_totalQ";
            this.lb_totalQ.Size = new System.Drawing.Size(152, 25);
            this.lb_totalQ.TabIndex = 50;
            this.lb_totalQ.Text = "Total Quantity:";
            // 
            // dgv_pesanan
            // 
            this.dgv_pesanan.AllowUserToResizeColumns = false;
            this.dgv_pesanan.AllowUserToResizeRows = false;
            this.dgv_pesanan.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv_pesanan.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_pesanan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_pesanan.Location = new System.Drawing.Point(635, 171);
            this.dgv_pesanan.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dgv_pesanan.Name = "dgv_pesanan";
            this.dgv_pesanan.ReadOnly = true;
            this.dgv_pesanan.RowHeadersVisible = false;
            this.dgv_pesanan.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dgv_pesanan.RowTemplate.Height = 33;
            this.dgv_pesanan.Size = new System.Drawing.Size(651, 425);
            this.dgv_pesanan.TabIndex = 49;
            // 
            // lb_daftarP
            // 
            this.lb_daftarP.AutoSize = true;
            this.lb_daftarP.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_daftarP.Location = new System.Drawing.Point(629, 128);
            this.lb_daftarP.Name = "lb_daftarP";
            this.lb_daftarP.Size = new System.Drawing.Size(182, 25);
            this.lb_daftarP.TabIndex = 48;
            this.lb_daftarP.Text = "Daftar Pesanan:";
            // 
            // lb_noTable
            // 
            this.lb_noTable.AutoSize = true;
            this.lb_noTable.Location = new System.Drawing.Point(929, 86);
            this.lb_noTable.Name = "lb_noTable";
            this.lb_noTable.Size = new System.Drawing.Size(153, 25);
            this.lb_noTable.TabIndex = 47;
            this.lb_noTable.Text = "Table Number:";
            // 
            // lb_ID
            // 
            this.lb_ID.AutoSize = true;
            this.lb_ID.Location = new System.Drawing.Point(929, 41);
            this.lb_ID.Name = "lb_ID";
            this.lb_ID.Size = new System.Drawing.Size(88, 25);
            this.lb_ID.TabIndex = 46;
            this.lb_ID.Text = "Staff ID:";
            // 
            // panel_tehtawar
            // 
            this.panel_tehtawar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel_tehtawar.Controls.Add(this.btn_minTehtawar);
            this.panel_tehtawar.Controls.Add(this.btn_addTehtawar);
            this.panel_tehtawar.Controls.Add(this.lb_pTehtawar);
            this.panel_tehtawar.Controls.Add(this.lb_tehtawar);
            this.panel_tehtawar.Controls.Add(this.pb_tehtawar);
            this.panel_tehtawar.Location = new System.Drawing.Point(419, 41);
            this.panel_tehtawar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_tehtawar.Name = "panel_tehtawar";
            this.panel_tehtawar.Size = new System.Drawing.Size(169, 228);
            this.panel_tehtawar.TabIndex = 59;
            // 
            // btn_minTehtawar
            // 
            this.btn_minTehtawar.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_minTehtawar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_minTehtawar.Location = new System.Drawing.Point(87, 186);
            this.btn_minTehtawar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_minTehtawar.Name = "btn_minTehtawar";
            this.btn_minTehtawar.Size = new System.Drawing.Size(40, 40);
            this.btn_minTehtawar.TabIndex = 25;
            this.btn_minTehtawar.Text = "-";
            this.btn_minTehtawar.UseVisualStyleBackColor = false;
            this.btn_minTehtawar.Click += new System.EventHandler(this.btn_minTehtawar_Click);
            // 
            // btn_addTehtawar
            // 
            this.btn_addTehtawar.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_addTehtawar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_addTehtawar.Location = new System.Drawing.Point(47, 186);
            this.btn_addTehtawar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_addTehtawar.Name = "btn_addTehtawar";
            this.btn_addTehtawar.Size = new System.Drawing.Size(40, 40);
            this.btn_addTehtawar.TabIndex = 24;
            this.btn_addTehtawar.Text = "+";
            this.btn_addTehtawar.UseVisualStyleBackColor = false;
            this.btn_addTehtawar.Click += new System.EventHandler(this.btn_addTehtawar_Click);
            // 
            // lb_pTehtawar
            // 
            this.lb_pTehtawar.AutoSize = true;
            this.lb_pTehtawar.Location = new System.Drawing.Point(13, 159);
            this.lb_pTehtawar.Name = "lb_pTehtawar";
            this.lb_pTehtawar.Size = new System.Drawing.Size(141, 25);
            this.lb_pTehtawar.TabIndex = 23;
            this.lb_pTehtawar.Text = "Rp 10.000,00";
            // 
            // lb_tehtawar
            // 
            this.lb_tehtawar.AutoSize = true;
            this.lb_tehtawar.Location = new System.Drawing.Point(12, 130);
            this.lb_tehtawar.Name = "lb_tehtawar";
            this.lb_tehtawar.Size = new System.Drawing.Size(145, 25);
            this.lb_tehtawar.TabIndex = 22;
            this.lb_tehtawar.Text = "Es Teh Tawar";
            // 
            // panel_tehmanis
            // 
            this.panel_tehmanis.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel_tehmanis.Controls.Add(this.btn_minTehmanis);
            this.panel_tehmanis.Controls.Add(this.btn_addTehmanis);
            this.panel_tehmanis.Controls.Add(this.lb_pTehmanis);
            this.panel_tehmanis.Controls.Add(this.lb_tehmanis);
            this.panel_tehmanis.Controls.Add(this.pb_tehmanis);
            this.panel_tehmanis.Location = new System.Drawing.Point(233, 41);
            this.panel_tehmanis.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_tehmanis.Name = "panel_tehmanis";
            this.panel_tehmanis.Size = new System.Drawing.Size(169, 228);
            this.panel_tehmanis.TabIndex = 58;
            // 
            // btn_minTehmanis
            // 
            this.btn_minTehmanis.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_minTehmanis.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_minTehmanis.Location = new System.Drawing.Point(88, 186);
            this.btn_minTehmanis.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_minTehmanis.Name = "btn_minTehmanis";
            this.btn_minTehmanis.Size = new System.Drawing.Size(40, 40);
            this.btn_minTehmanis.TabIndex = 25;
            this.btn_minTehmanis.Text = "-";
            this.btn_minTehmanis.UseVisualStyleBackColor = false;
            this.btn_minTehmanis.Click += new System.EventHandler(this.btn_minTehmanis_Click);
            // 
            // btn_addTehmanis
            // 
            this.btn_addTehmanis.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_addTehmanis.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_addTehmanis.Location = new System.Drawing.Point(48, 186);
            this.btn_addTehmanis.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_addTehmanis.Name = "btn_addTehmanis";
            this.btn_addTehmanis.Size = new System.Drawing.Size(40, 40);
            this.btn_addTehmanis.TabIndex = 24;
            this.btn_addTehmanis.Text = "+";
            this.btn_addTehmanis.UseVisualStyleBackColor = false;
            this.btn_addTehmanis.Click += new System.EventHandler(this.btn_addTehmanis_Click);
            // 
            // lb_pTehmanis
            // 
            this.lb_pTehmanis.AutoSize = true;
            this.lb_pTehmanis.Location = new System.Drawing.Point(13, 159);
            this.lb_pTehmanis.Name = "lb_pTehmanis";
            this.lb_pTehmanis.Size = new System.Drawing.Size(141, 25);
            this.lb_pTehmanis.TabIndex = 23;
            this.lb_pTehmanis.Text = "Rp 12.000,00";
            // 
            // lb_tehmanis
            // 
            this.lb_tehmanis.AutoSize = true;
            this.lb_tehmanis.Location = new System.Drawing.Point(12, 130);
            this.lb_tehmanis.Name = "lb_tehmanis";
            this.lb_tehmanis.Size = new System.Drawing.Size(144, 25);
            this.lb_tehmanis.TabIndex = 22;
            this.lb_tehmanis.Text = "Es Teh Manis";
            // 
            // panel_air
            // 
            this.panel_air.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel_air.Controls.Add(this.btn_minAir);
            this.panel_air.Controls.Add(this.btn_addAir);
            this.panel_air.Controls.Add(this.lb_pAir);
            this.panel_air.Controls.Add(this.lb_air);
            this.panel_air.Controls.Add(this.pb_air);
            this.panel_air.Location = new System.Drawing.Point(49, 41);
            this.panel_air.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_air.Name = "panel_air";
            this.panel_air.Size = new System.Drawing.Size(169, 228);
            this.panel_air.TabIndex = 57;
            // 
            // btn_minAir
            // 
            this.btn_minAir.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_minAir.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_minAir.Location = new System.Drawing.Point(87, 186);
            this.btn_minAir.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_minAir.Name = "btn_minAir";
            this.btn_minAir.Size = new System.Drawing.Size(40, 40);
            this.btn_minAir.TabIndex = 25;
            this.btn_minAir.Text = "-";
            this.btn_minAir.UseVisualStyleBackColor = false;
            this.btn_minAir.Click += new System.EventHandler(this.btn_minAir_Click);
            // 
            // btn_addAir
            // 
            this.btn_addAir.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_addAir.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_addAir.Location = new System.Drawing.Point(47, 186);
            this.btn_addAir.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_addAir.Name = "btn_addAir";
            this.btn_addAir.Size = new System.Drawing.Size(40, 40);
            this.btn_addAir.TabIndex = 24;
            this.btn_addAir.Text = "+";
            this.btn_addAir.UseVisualStyleBackColor = false;
            this.btn_addAir.Click += new System.EventHandler(this.btn_addAir_Click);
            // 
            // lb_pAir
            // 
            this.lb_pAir.AutoSize = true;
            this.lb_pAir.Location = new System.Drawing.Point(15, 159);
            this.lb_pAir.Name = "lb_pAir";
            this.lb_pAir.Size = new System.Drawing.Size(141, 25);
            this.lb_pAir.TabIndex = 23;
            this.lb_pAir.Text = "Rp 10.000,00";
            // 
            // lb_air
            // 
            this.lb_air.AutoSize = true;
            this.lb_air.Location = new System.Drawing.Point(28, 130);
            this.lb_air.Name = "lb_air";
            this.lb_air.Size = new System.Drawing.Size(115, 25);
            this.lb_air.TabIndex = 22;
            this.lb_air.Text = "Air Mineral";
            // 
            // panel_cendol
            // 
            this.panel_cendol.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel_cendol.Controls.Add(this.btn_minCendol);
            this.panel_cendol.Controls.Add(this.btn_addCendol);
            this.panel_cendol.Controls.Add(this.lb_pCendol);
            this.panel_cendol.Controls.Add(this.lb_cendol);
            this.panel_cendol.Controls.Add(this.pb_cendol);
            this.panel_cendol.Location = new System.Drawing.Point(419, 281);
            this.panel_cendol.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_cendol.Name = "panel_cendol";
            this.panel_cendol.Size = new System.Drawing.Size(169, 228);
            this.panel_cendol.TabIndex = 62;
            // 
            // btn_minCendol
            // 
            this.btn_minCendol.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_minCendol.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_minCendol.Location = new System.Drawing.Point(87, 186);
            this.btn_minCendol.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_minCendol.Name = "btn_minCendol";
            this.btn_minCendol.Size = new System.Drawing.Size(40, 40);
            this.btn_minCendol.TabIndex = 25;
            this.btn_minCendol.Text = "-";
            this.btn_minCendol.UseVisualStyleBackColor = false;
            this.btn_minCendol.Click += new System.EventHandler(this.btn_minCendol_Click);
            // 
            // btn_addCendol
            // 
            this.btn_addCendol.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_addCendol.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_addCendol.Location = new System.Drawing.Point(47, 186);
            this.btn_addCendol.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_addCendol.Name = "btn_addCendol";
            this.btn_addCendol.Size = new System.Drawing.Size(40, 40);
            this.btn_addCendol.TabIndex = 24;
            this.btn_addCendol.Text = "+";
            this.btn_addCendol.UseVisualStyleBackColor = false;
            this.btn_addCendol.Click += new System.EventHandler(this.btn_addCendol_Click);
            // 
            // lb_pCendol
            // 
            this.lb_pCendol.AutoSize = true;
            this.lb_pCendol.Location = new System.Drawing.Point(13, 159);
            this.lb_pCendol.Name = "lb_pCendol";
            this.lb_pCendol.Size = new System.Drawing.Size(141, 25);
            this.lb_pCendol.TabIndex = 23;
            this.lb_pCendol.Text = "Rp 20.000,00";
            // 
            // lb_cendol
            // 
            this.lb_cendol.AutoSize = true;
            this.lb_cendol.Location = new System.Drawing.Point(28, 130);
            this.lb_cendol.Name = "lb_cendol";
            this.lb_cendol.Size = new System.Drawing.Size(111, 25);
            this.lb_cendol.TabIndex = 22;
            this.lb_cendol.Text = "Es Cendol";
            // 
            // panel_jernip
            // 
            this.panel_jernip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel_jernip.Controls.Add(this.btn_minJernip);
            this.panel_jernip.Controls.Add(this.btn_addJernip);
            this.panel_jernip.Controls.Add(this.lb_pJernip);
            this.panel_jernip.Controls.Add(this.lb_jernip);
            this.panel_jernip.Controls.Add(this.pb_jernip);
            this.panel_jernip.Location = new System.Drawing.Point(233, 281);
            this.panel_jernip.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_jernip.Name = "panel_jernip";
            this.panel_jernip.Size = new System.Drawing.Size(169, 228);
            this.panel_jernip.TabIndex = 61;
            // 
            // btn_minJernip
            // 
            this.btn_minJernip.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_minJernip.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_minJernip.Location = new System.Drawing.Point(87, 186);
            this.btn_minJernip.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_minJernip.Name = "btn_minJernip";
            this.btn_minJernip.Size = new System.Drawing.Size(40, 40);
            this.btn_minJernip.TabIndex = 25;
            this.btn_minJernip.Text = "-";
            this.btn_minJernip.UseVisualStyleBackColor = false;
            this.btn_minJernip.Click += new System.EventHandler(this.btn_minJernip_Click);
            // 
            // btn_addJernip
            // 
            this.btn_addJernip.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_addJernip.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_addJernip.Location = new System.Drawing.Point(47, 186);
            this.btn_addJernip.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_addJernip.Name = "btn_addJernip";
            this.btn_addJernip.Size = new System.Drawing.Size(40, 40);
            this.btn_addJernip.TabIndex = 24;
            this.btn_addJernip.Text = "+";
            this.btn_addJernip.UseVisualStyleBackColor = false;
            this.btn_addJernip.Click += new System.EventHandler(this.btn_addJernip_Click);
            // 
            // lb_pJernip
            // 
            this.lb_pJernip.AutoSize = true;
            this.lb_pJernip.Location = new System.Drawing.Point(13, 159);
            this.lb_pJernip.Name = "lb_pJernip";
            this.lb_pJernip.Size = new System.Drawing.Size(141, 25);
            this.lb_pJernip.TabIndex = 23;
            this.lb_pJernip.Text = "Rp 12.000,00";
            // 
            // lb_jernip
            // 
            this.lb_jernip.AutoSize = true;
            this.lb_jernip.Location = new System.Drawing.Point(9, 130);
            this.lb_jernip.Name = "lb_jernip";
            this.lb_jernip.Size = new System.Drawing.Size(150, 25);
            this.lb_jernip.TabIndex = 22;
            this.lb_jernip.Text = "Es Jeruk Nipis";
            // 
            // panel_jeruk
            // 
            this.panel_jeruk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel_jeruk.Controls.Add(this.btn_minJeruk);
            this.panel_jeruk.Controls.Add(this.btn_addJeruk);
            this.panel_jeruk.Controls.Add(this.lb_pJeruk);
            this.panel_jeruk.Controls.Add(this.lb_jeruk);
            this.panel_jeruk.Controls.Add(this.pb_jeruk);
            this.panel_jeruk.Location = new System.Drawing.Point(49, 281);
            this.panel_jeruk.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_jeruk.Name = "panel_jeruk";
            this.panel_jeruk.Size = new System.Drawing.Size(169, 228);
            this.panel_jeruk.TabIndex = 60;
            // 
            // btn_minJeruk
            // 
            this.btn_minJeruk.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_minJeruk.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_minJeruk.Location = new System.Drawing.Point(87, 186);
            this.btn_minJeruk.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_minJeruk.Name = "btn_minJeruk";
            this.btn_minJeruk.Size = new System.Drawing.Size(40, 40);
            this.btn_minJeruk.TabIndex = 25;
            this.btn_minJeruk.Text = "-";
            this.btn_minJeruk.UseVisualStyleBackColor = false;
            this.btn_minJeruk.Click += new System.EventHandler(this.btn_minJeruk_Click);
            // 
            // btn_addJeruk
            // 
            this.btn_addJeruk.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_addJeruk.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_addJeruk.Location = new System.Drawing.Point(47, 186);
            this.btn_addJeruk.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_addJeruk.Name = "btn_addJeruk";
            this.btn_addJeruk.Size = new System.Drawing.Size(40, 40);
            this.btn_addJeruk.TabIndex = 24;
            this.btn_addJeruk.Text = "+";
            this.btn_addJeruk.UseVisualStyleBackColor = false;
            this.btn_addJeruk.Click += new System.EventHandler(this.btn_addJeruk_Click);
            // 
            // lb_pJeruk
            // 
            this.lb_pJeruk.AutoSize = true;
            this.lb_pJeruk.Location = new System.Drawing.Point(13, 159);
            this.lb_pJeruk.Name = "lb_pJeruk";
            this.lb_pJeruk.Size = new System.Drawing.Size(141, 25);
            this.lb_pJeruk.TabIndex = 23;
            this.lb_pJeruk.Text = "Rp 15.000,00";
            // 
            // lb_jeruk
            // 
            this.lb_jeruk.AutoSize = true;
            this.lb_jeruk.Location = new System.Drawing.Point(4, 130);
            this.lb_jeruk.Name = "lb_jeruk";
            this.lb_jeruk.Size = new System.Drawing.Size(160, 25);
            this.lb_jeruk.TabIndex = 22;
            this.lb_jeruk.Text = "Es Jeruk Manis";
            // 
            // panel_sirsak
            // 
            this.panel_sirsak.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel_sirsak.Controls.Add(this.btn_minSirsak);
            this.panel_sirsak.Controls.Add(this.btn_addSirsak);
            this.panel_sirsak.Controls.Add(this.lb_pSirsak);
            this.panel_sirsak.Controls.Add(this.lb_sirsak);
            this.panel_sirsak.Controls.Add(this.pb_sirsak);
            this.panel_sirsak.Location = new System.Drawing.Point(419, 764);
            this.panel_sirsak.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_sirsak.Name = "panel_sirsak";
            this.panel_sirsak.Size = new System.Drawing.Size(169, 228);
            this.panel_sirsak.TabIndex = 68;
            // 
            // btn_minSirsak
            // 
            this.btn_minSirsak.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_minSirsak.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_minSirsak.Location = new System.Drawing.Point(87, 186);
            this.btn_minSirsak.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_minSirsak.Name = "btn_minSirsak";
            this.btn_minSirsak.Size = new System.Drawing.Size(40, 40);
            this.btn_minSirsak.TabIndex = 25;
            this.btn_minSirsak.Text = "-";
            this.btn_minSirsak.UseVisualStyleBackColor = false;
            this.btn_minSirsak.Click += new System.EventHandler(this.btn_minSirsak_Click);
            // 
            // btn_addSirsak
            // 
            this.btn_addSirsak.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_addSirsak.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_addSirsak.Location = new System.Drawing.Point(47, 186);
            this.btn_addSirsak.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_addSirsak.Name = "btn_addSirsak";
            this.btn_addSirsak.Size = new System.Drawing.Size(40, 40);
            this.btn_addSirsak.TabIndex = 24;
            this.btn_addSirsak.Text = "+";
            this.btn_addSirsak.UseVisualStyleBackColor = false;
            this.btn_addSirsak.Click += new System.EventHandler(this.btn_addSirsak_Click);
            // 
            // lb_pSirsak
            // 
            this.lb_pSirsak.AutoSize = true;
            this.lb_pSirsak.Location = new System.Drawing.Point(13, 159);
            this.lb_pSirsak.Name = "lb_pSirsak";
            this.lb_pSirsak.Size = new System.Drawing.Size(141, 25);
            this.lb_pSirsak.TabIndex = 23;
            this.lb_pSirsak.Text = "Rp 20.000,00";
            // 
            // lb_sirsak
            // 
            this.lb_sirsak.AutoSize = true;
            this.lb_sirsak.Location = new System.Drawing.Point(28, 130);
            this.lb_sirsak.Name = "lb_sirsak";
            this.lb_sirsak.Size = new System.Drawing.Size(112, 25);
            this.lb_sirsak.TabIndex = 22;
            this.lb_sirsak.Text = "Jus Sirsak";
            // 
            // panel_tehtarik
            // 
            this.panel_tehtarik.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel_tehtarik.Controls.Add(this.btn_minTehTarik);
            this.panel_tehtarik.Controls.Add(this.btn_addTehtarik);
            this.panel_tehtarik.Controls.Add(this.lb_pTehtarik);
            this.panel_tehtarik.Controls.Add(this.lb_tehtarik);
            this.panel_tehtarik.Controls.Add(this.pb_tektarik);
            this.panel_tehtarik.Location = new System.Drawing.Point(419, 524);
            this.panel_tehtarik.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_tehtarik.Name = "panel_tehtarik";
            this.panel_tehtarik.Size = new System.Drawing.Size(169, 228);
            this.panel_tehtarik.TabIndex = 65;
            // 
            // btn_minTehTarik
            // 
            this.btn_minTehTarik.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_minTehTarik.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_minTehTarik.Location = new System.Drawing.Point(87, 186);
            this.btn_minTehTarik.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_minTehTarik.Name = "btn_minTehTarik";
            this.btn_minTehTarik.Size = new System.Drawing.Size(40, 40);
            this.btn_minTehTarik.TabIndex = 25;
            this.btn_minTehTarik.Text = "-";
            this.btn_minTehTarik.UseVisualStyleBackColor = false;
            this.btn_minTehTarik.Click += new System.EventHandler(this.btn_minTehTarik_Click);
            // 
            // btn_addTehtarik
            // 
            this.btn_addTehtarik.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_addTehtarik.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_addTehtarik.Location = new System.Drawing.Point(47, 186);
            this.btn_addTehtarik.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_addTehtarik.Name = "btn_addTehtarik";
            this.btn_addTehtarik.Size = new System.Drawing.Size(40, 40);
            this.btn_addTehtarik.TabIndex = 24;
            this.btn_addTehtarik.Text = "+";
            this.btn_addTehtarik.UseVisualStyleBackColor = false;
            this.btn_addTehtarik.Click += new System.EventHandler(this.btn_addTehtarik_Click);
            // 
            // lb_pTehtarik
            // 
            this.lb_pTehtarik.AutoSize = true;
            this.lb_pTehtarik.Location = new System.Drawing.Point(13, 159);
            this.lb_pTehtarik.Name = "lb_pTehtarik";
            this.lb_pTehtarik.Size = new System.Drawing.Size(141, 25);
            this.lb_pTehtarik.TabIndex = 23;
            this.lb_pTehtarik.Text = "Rp 15.000,00";
            // 
            // lb_tehtarik
            // 
            this.lb_tehtarik.AutoSize = true;
            this.lb_tehtarik.Location = new System.Drawing.Point(31, 130);
            this.lb_tehtarik.Name = "lb_tehtarik";
            this.lb_tehtarik.Size = new System.Drawing.Size(103, 25);
            this.lb_tehtarik.TabIndex = 22;
            this.lb_tehtarik.Text = "Teh Tarik";
            // 
            // panel_alpukat
            // 
            this.panel_alpukat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel_alpukat.Controls.Add(this.btn_minAlpukat);
            this.panel_alpukat.Controls.Add(this.btn_addAlpukat);
            this.panel_alpukat.Controls.Add(this.lb_pAlpukat);
            this.panel_alpukat.Controls.Add(this.lb_alpukat);
            this.panel_alpukat.Controls.Add(this.pb_alpukat);
            this.panel_alpukat.Location = new System.Drawing.Point(233, 764);
            this.panel_alpukat.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_alpukat.Name = "panel_alpukat";
            this.panel_alpukat.Size = new System.Drawing.Size(169, 228);
            this.panel_alpukat.TabIndex = 67;
            // 
            // btn_minAlpukat
            // 
            this.btn_minAlpukat.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_minAlpukat.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_minAlpukat.Location = new System.Drawing.Point(87, 186);
            this.btn_minAlpukat.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_minAlpukat.Name = "btn_minAlpukat";
            this.btn_minAlpukat.Size = new System.Drawing.Size(40, 40);
            this.btn_minAlpukat.TabIndex = 25;
            this.btn_minAlpukat.Text = "-";
            this.btn_minAlpukat.UseVisualStyleBackColor = false;
            this.btn_minAlpukat.Click += new System.EventHandler(this.btn_minAlpukat_Click);
            // 
            // btn_addAlpukat
            // 
            this.btn_addAlpukat.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_addAlpukat.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_addAlpukat.Location = new System.Drawing.Point(47, 186);
            this.btn_addAlpukat.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_addAlpukat.Name = "btn_addAlpukat";
            this.btn_addAlpukat.Size = new System.Drawing.Size(40, 40);
            this.btn_addAlpukat.TabIndex = 24;
            this.btn_addAlpukat.Text = "+";
            this.btn_addAlpukat.UseVisualStyleBackColor = false;
            this.btn_addAlpukat.Click += new System.EventHandler(this.btn_addAlpukat_Click);
            // 
            // lb_pAlpukat
            // 
            this.lb_pAlpukat.AutoSize = true;
            this.lb_pAlpukat.Location = new System.Drawing.Point(13, 159);
            this.lb_pAlpukat.Name = "lb_pAlpukat";
            this.lb_pAlpukat.Size = new System.Drawing.Size(141, 25);
            this.lb_pAlpukat.TabIndex = 23;
            this.lb_pAlpukat.Text = "Rp 20.000,00";
            // 
            // lb_alpukat
            // 
            this.lb_alpukat.AutoSize = true;
            this.lb_alpukat.Location = new System.Drawing.Point(23, 130);
            this.lb_alpukat.Name = "lb_alpukat";
            this.lb_alpukat.Size = new System.Drawing.Size(124, 25);
            this.lb_alpukat.TabIndex = 22;
            this.lb_alpukat.Text = "Jus Alpukat";
            // 
            // panel_jahe
            // 
            this.panel_jahe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel_jahe.Controls.Add(this.btn_minJahe);
            this.panel_jahe.Controls.Add(this.btn_addJahe);
            this.panel_jahe.Controls.Add(this.lb_pJahe);
            this.panel_jahe.Controls.Add(this.lb_jahe);
            this.panel_jahe.Controls.Add(this.pb_jahe);
            this.panel_jahe.Location = new System.Drawing.Point(233, 524);
            this.panel_jahe.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_jahe.Name = "panel_jahe";
            this.panel_jahe.Size = new System.Drawing.Size(169, 228);
            this.panel_jahe.TabIndex = 64;
            // 
            // btn_minJahe
            // 
            this.btn_minJahe.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_minJahe.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_minJahe.Location = new System.Drawing.Point(87, 186);
            this.btn_minJahe.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_minJahe.Name = "btn_minJahe";
            this.btn_minJahe.Size = new System.Drawing.Size(40, 40);
            this.btn_minJahe.TabIndex = 25;
            this.btn_minJahe.Text = "-";
            this.btn_minJahe.UseVisualStyleBackColor = false;
            this.btn_minJahe.Click += new System.EventHandler(this.btn_minJahe_Click);
            // 
            // btn_addJahe
            // 
            this.btn_addJahe.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_addJahe.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_addJahe.Location = new System.Drawing.Point(47, 186);
            this.btn_addJahe.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_addJahe.Name = "btn_addJahe";
            this.btn_addJahe.Size = new System.Drawing.Size(40, 40);
            this.btn_addJahe.TabIndex = 24;
            this.btn_addJahe.Text = "+";
            this.btn_addJahe.UseVisualStyleBackColor = false;
            this.btn_addJahe.Click += new System.EventHandler(this.btn_addJahe_Click);
            // 
            // lb_pJahe
            // 
            this.lb_pJahe.AutoSize = true;
            this.lb_pJahe.Location = new System.Drawing.Point(13, 159);
            this.lb_pJahe.Name = "lb_pJahe";
            this.lb_pJahe.Size = new System.Drawing.Size(141, 25);
            this.lb_pJahe.TabIndex = 23;
            this.lb_pJahe.Text = "Rp 15.000,00";
            // 
            // lb_jahe
            // 
            this.lb_jahe.AutoSize = true;
            this.lb_jahe.Location = new System.Drawing.Point(12, 130);
            this.lb_jahe.Name = "lb_jahe";
            this.lb_jahe.Size = new System.Drawing.Size(145, 25);
            this.lb_jahe.TabIndex = 22;
            this.lb_jahe.Text = "Wedang Jahe";
            // 
            // panel_buah
            // 
            this.panel_buah.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel_buah.Controls.Add(this.btn_minBuah);
            this.panel_buah.Controls.Add(this.btn_addBuah);
            this.panel_buah.Controls.Add(this.lb_pBuah);
            this.panel_buah.Controls.Add(this.lb_buah);
            this.panel_buah.Controls.Add(this.pb_buah);
            this.panel_buah.Location = new System.Drawing.Point(49, 764);
            this.panel_buah.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_buah.Name = "panel_buah";
            this.panel_buah.Size = new System.Drawing.Size(169, 228);
            this.panel_buah.TabIndex = 66;
            // 
            // btn_minBuah
            // 
            this.btn_minBuah.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_minBuah.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_minBuah.Location = new System.Drawing.Point(87, 186);
            this.btn_minBuah.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_minBuah.Name = "btn_minBuah";
            this.btn_minBuah.Size = new System.Drawing.Size(40, 40);
            this.btn_minBuah.TabIndex = 25;
            this.btn_minBuah.Text = "-";
            this.btn_minBuah.UseVisualStyleBackColor = false;
            this.btn_minBuah.Click += new System.EventHandler(this.btn_minBuah_Click);
            // 
            // btn_addBuah
            // 
            this.btn_addBuah.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_addBuah.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_addBuah.Location = new System.Drawing.Point(47, 186);
            this.btn_addBuah.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_addBuah.Name = "btn_addBuah";
            this.btn_addBuah.Size = new System.Drawing.Size(40, 40);
            this.btn_addBuah.TabIndex = 24;
            this.btn_addBuah.Text = "+";
            this.btn_addBuah.UseVisualStyleBackColor = false;
            this.btn_addBuah.Click += new System.EventHandler(this.btn_addBuah_Click);
            // 
            // lb_pBuah
            // 
            this.lb_pBuah.AutoSize = true;
            this.lb_pBuah.Location = new System.Drawing.Point(15, 159);
            this.lb_pBuah.Name = "lb_pBuah";
            this.lb_pBuah.Size = new System.Drawing.Size(141, 25);
            this.lb_pBuah.TabIndex = 23;
            this.lb_pBuah.Text = "Rp 25.000,00";
            // 
            // lb_buah
            // 
            this.lb_buah.AutoSize = true;
            this.lb_buah.Location = new System.Drawing.Point(40, 130);
            this.lb_buah.Name = "lb_buah";
            this.lb_buah.Size = new System.Drawing.Size(93, 25);
            this.lb_buah.TabIndex = 22;
            this.lb_buah.Text = "Es Buah";
            // 
            // panel_degan
            // 
            this.panel_degan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel_degan.Controls.Add(this.btn_minDegan);
            this.panel_degan.Controls.Add(this.btn_addDegan);
            this.panel_degan.Controls.Add(this.lb_pDegan);
            this.panel_degan.Controls.Add(this.lb_degan);
            this.panel_degan.Controls.Add(this.pb_degan);
            this.panel_degan.Location = new System.Drawing.Point(49, 524);
            this.panel_degan.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_degan.Name = "panel_degan";
            this.panel_degan.Size = new System.Drawing.Size(169, 228);
            this.panel_degan.TabIndex = 63;
            // 
            // btn_minDegan
            // 
            this.btn_minDegan.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_minDegan.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_minDegan.Location = new System.Drawing.Point(87, 186);
            this.btn_minDegan.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_minDegan.Name = "btn_minDegan";
            this.btn_minDegan.Size = new System.Drawing.Size(40, 40);
            this.btn_minDegan.TabIndex = 25;
            this.btn_minDegan.Text = "-";
            this.btn_minDegan.UseVisualStyleBackColor = false;
            this.btn_minDegan.Click += new System.EventHandler(this.btn_minDegan_Click);
            // 
            // btn_addDegan
            // 
            this.btn_addDegan.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_addDegan.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_addDegan.Location = new System.Drawing.Point(47, 186);
            this.btn_addDegan.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_addDegan.Name = "btn_addDegan";
            this.btn_addDegan.Size = new System.Drawing.Size(40, 40);
            this.btn_addDegan.TabIndex = 24;
            this.btn_addDegan.Text = "+";
            this.btn_addDegan.UseVisualStyleBackColor = false;
            this.btn_addDegan.Click += new System.EventHandler(this.btn_addDegan_Click);
            // 
            // lb_pDegan
            // 
            this.lb_pDegan.AutoSize = true;
            this.lb_pDegan.Location = new System.Drawing.Point(13, 159);
            this.lb_pDegan.Name = "lb_pDegan";
            this.lb_pDegan.Size = new System.Drawing.Size(141, 25);
            this.lb_pDegan.TabIndex = 23;
            this.lb_pDegan.Text = "Rp 25.000,00";
            // 
            // lb_degan
            // 
            this.lb_degan.AutoSize = true;
            this.lb_degan.Location = new System.Drawing.Point(32, 130);
            this.lb_degan.Name = "lb_degan";
            this.lb_degan.Size = new System.Drawing.Size(106, 25);
            this.lb_degan.TabIndex = 22;
            this.lb_degan.Text = "Es Degan";
            // 
            // panel_naga
            // 
            this.panel_naga.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel_naga.Controls.Add(this.btn_minNaga);
            this.panel_naga.Controls.Add(this.btn_addNaga);
            this.panel_naga.Controls.Add(this.lb_pNaga);
            this.panel_naga.Controls.Add(this.lb_naga);
            this.panel_naga.Controls.Add(this.pb_naga);
            this.panel_naga.Location = new System.Drawing.Point(232, 1004);
            this.panel_naga.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_naga.Name = "panel_naga";
            this.panel_naga.Size = new System.Drawing.Size(169, 228);
            this.panel_naga.TabIndex = 70;
            // 
            // btn_minNaga
            // 
            this.btn_minNaga.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_minNaga.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_minNaga.Location = new System.Drawing.Point(87, 186);
            this.btn_minNaga.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_minNaga.Name = "btn_minNaga";
            this.btn_minNaga.Size = new System.Drawing.Size(40, 40);
            this.btn_minNaga.TabIndex = 25;
            this.btn_minNaga.Text = "-";
            this.btn_minNaga.UseVisualStyleBackColor = false;
            this.btn_minNaga.Click += new System.EventHandler(this.btn_minNaga_Click);
            // 
            // btn_addNaga
            // 
            this.btn_addNaga.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_addNaga.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_addNaga.Location = new System.Drawing.Point(47, 186);
            this.btn_addNaga.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_addNaga.Name = "btn_addNaga";
            this.btn_addNaga.Size = new System.Drawing.Size(40, 40);
            this.btn_addNaga.TabIndex = 24;
            this.btn_addNaga.Text = "+";
            this.btn_addNaga.UseVisualStyleBackColor = false;
            this.btn_addNaga.Click += new System.EventHandler(this.btn_addNaga_Click);
            // 
            // lb_pNaga
            // 
            this.lb_pNaga.AutoSize = true;
            this.lb_pNaga.Location = new System.Drawing.Point(13, 159);
            this.lb_pNaga.Name = "lb_pNaga";
            this.lb_pNaga.Size = new System.Drawing.Size(141, 25);
            this.lb_pNaga.TabIndex = 23;
            this.lb_pNaga.Text = "Rp 20.000,00";
            // 
            // lb_naga
            // 
            this.lb_naga.AutoSize = true;
            this.lb_naga.Location = new System.Drawing.Point(5, 130);
            this.lb_naga.Name = "lb_naga";
            this.lb_naga.Size = new System.Drawing.Size(159, 25);
            this.lb_naga.TabIndex = 22;
            this.lb_naga.Text = "Jus Buah Naga";
            // 
            // panel_mangga
            // 
            this.panel_mangga.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel_mangga.Controls.Add(this.btn_minMangga);
            this.panel_mangga.Controls.Add(this.btn_addMangga);
            this.panel_mangga.Controls.Add(this.lb_pMangga);
            this.panel_mangga.Controls.Add(this.lb_mangga);
            this.panel_mangga.Controls.Add(this.pb_mangga);
            this.panel_mangga.Location = new System.Drawing.Point(48, 1004);
            this.panel_mangga.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_mangga.Name = "panel_mangga";
            this.panel_mangga.Size = new System.Drawing.Size(169, 228);
            this.panel_mangga.TabIndex = 69;
            // 
            // btn_minMangga
            // 
            this.btn_minMangga.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_minMangga.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_minMangga.Location = new System.Drawing.Point(87, 186);
            this.btn_minMangga.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_minMangga.Name = "btn_minMangga";
            this.btn_minMangga.Size = new System.Drawing.Size(40, 40);
            this.btn_minMangga.TabIndex = 25;
            this.btn_minMangga.Text = "-";
            this.btn_minMangga.UseVisualStyleBackColor = false;
            this.btn_minMangga.Click += new System.EventHandler(this.btn_minMangga_Click);
            // 
            // btn_addMangga
            // 
            this.btn_addMangga.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_addMangga.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_addMangga.Location = new System.Drawing.Point(47, 186);
            this.btn_addMangga.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_addMangga.Name = "btn_addMangga";
            this.btn_addMangga.Size = new System.Drawing.Size(40, 40);
            this.btn_addMangga.TabIndex = 24;
            this.btn_addMangga.Text = "+";
            this.btn_addMangga.UseVisualStyleBackColor = false;
            this.btn_addMangga.Click += new System.EventHandler(this.btn_addMangga_Click);
            // 
            // lb_pMangga
            // 
            this.lb_pMangga.AutoSize = true;
            this.lb_pMangga.Location = new System.Drawing.Point(13, 159);
            this.lb_pMangga.Name = "lb_pMangga";
            this.lb_pMangga.Size = new System.Drawing.Size(141, 25);
            this.lb_pMangga.TabIndex = 23;
            this.lb_pMangga.Text = "Rp 20.000,00";
            // 
            // lb_mangga
            // 
            this.lb_mangga.AutoSize = true;
            this.lb_mangga.Location = new System.Drawing.Point(19, 130);
            this.lb_mangga.Name = "lb_mangga";
            this.lb_mangga.Size = new System.Drawing.Size(130, 25);
            this.lb_mangga.TabIndex = 22;
            this.lb_mangga.Text = "Jus Mangga";
            // 
            // stat_date
            // 
            this.stat_date.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.stat_date.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dateStatus});
            this.stat_date.Location = new System.Drawing.Point(0, 1232);
            this.stat_date.Name = "stat_date";
            this.stat_date.Padding = new System.Windows.Forms.Padding(1, 0, 19, 0);
            this.stat_date.Size = new System.Drawing.Size(1325, 42);
            this.stat_date.TabIndex = 71;
            this.stat_date.Text = "statusStrip1";
            // 
            // dateStatus
            // 
            this.dateStatus.Name = "dateStatus";
            this.dateStatus.Size = new System.Drawing.Size(237, 32);
            this.dateStatus.Text = "toolStripStatusLabel1";
            // 
            // timer_kasir
            // 
            this.timer_kasir.Enabled = true;
            this.timer_kasir.Interval = 1000;
            this.timer_kasir.Tick += new System.EventHandler(this.timer_kasir_Tick);
            // 
            // pb_naga
            // 
            this.pb_naga.Image = global::ALP.Properties.Resources.Jus_Buah_Naga;
            this.pb_naga.Location = new System.Drawing.Point(9, 6);
            this.pb_naga.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pb_naga.Name = "pb_naga";
            this.pb_naga.Size = new System.Drawing.Size(149, 120);
            this.pb_naga.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_naga.TabIndex = 21;
            this.pb_naga.TabStop = false;
            // 
            // pb_sirsak
            // 
            this.pb_sirsak.Image = global::ALP.Properties.Resources.Jus_Sirsak;
            this.pb_sirsak.Location = new System.Drawing.Point(9, 6);
            this.pb_sirsak.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pb_sirsak.Name = "pb_sirsak";
            this.pb_sirsak.Size = new System.Drawing.Size(149, 120);
            this.pb_sirsak.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_sirsak.TabIndex = 21;
            this.pb_sirsak.TabStop = false;
            // 
            // pb_mangga
            // 
            this.pb_mangga.Image = global::ALP.Properties.Resources.Jus_Mangga;
            this.pb_mangga.Location = new System.Drawing.Point(9, 6);
            this.pb_mangga.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pb_mangga.Name = "pb_mangga";
            this.pb_mangga.Size = new System.Drawing.Size(149, 120);
            this.pb_mangga.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_mangga.TabIndex = 21;
            this.pb_mangga.TabStop = false;
            // 
            // pb_cendol
            // 
            this.pb_cendol.Image = global::ALP.Properties.Resources.Es_Cendol;
            this.pb_cendol.Location = new System.Drawing.Point(9, 6);
            this.pb_cendol.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pb_cendol.Name = "pb_cendol";
            this.pb_cendol.Size = new System.Drawing.Size(149, 120);
            this.pb_cendol.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_cendol.TabIndex = 21;
            this.pb_cendol.TabStop = false;
            // 
            // pb_tektarik
            // 
            this.pb_tektarik.Image = global::ALP.Properties.Resources.Teh_Tarik;
            this.pb_tektarik.Location = new System.Drawing.Point(9, 6);
            this.pb_tektarik.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pb_tektarik.Name = "pb_tektarik";
            this.pb_tektarik.Size = new System.Drawing.Size(149, 120);
            this.pb_tektarik.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_tektarik.TabIndex = 21;
            this.pb_tektarik.TabStop = false;
            // 
            // pb_tehtawar
            // 
            this.pb_tehtawar.Image = global::ALP.Properties.Resources.Es_teh_manis;
            this.pb_tehtawar.Location = new System.Drawing.Point(9, 6);
            this.pb_tehtawar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pb_tehtawar.Name = "pb_tehtawar";
            this.pb_tehtawar.Size = new System.Drawing.Size(149, 120);
            this.pb_tehtawar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_tehtawar.TabIndex = 21;
            this.pb_tehtawar.TabStop = false;
            // 
            // pb_alpukat
            // 
            this.pb_alpukat.Image = global::ALP.Properties.Resources.Jus_Alpukat;
            this.pb_alpukat.Location = new System.Drawing.Point(9, 6);
            this.pb_alpukat.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pb_alpukat.Name = "pb_alpukat";
            this.pb_alpukat.Size = new System.Drawing.Size(149, 120);
            this.pb_alpukat.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_alpukat.TabIndex = 21;
            this.pb_alpukat.TabStop = false;
            // 
            // pb_jernip
            // 
            this.pb_jernip.Image = global::ALP.Properties.Resources.Es_Jeruk_Nipis;
            this.pb_jernip.Location = new System.Drawing.Point(9, 6);
            this.pb_jernip.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pb_jernip.Name = "pb_jernip";
            this.pb_jernip.Size = new System.Drawing.Size(149, 120);
            this.pb_jernip.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_jernip.TabIndex = 21;
            this.pb_jernip.TabStop = false;
            // 
            // pb_jahe
            // 
            this.pb_jahe.Image = global::ALP.Properties.Resources.Wedang_Jahe;
            this.pb_jahe.Location = new System.Drawing.Point(9, 6);
            this.pb_jahe.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pb_jahe.Name = "pb_jahe";
            this.pb_jahe.Size = new System.Drawing.Size(149, 120);
            this.pb_jahe.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_jahe.TabIndex = 21;
            this.pb_jahe.TabStop = false;
            // 
            // pb_tehmanis
            // 
            this.pb_tehmanis.Image = global::ALP.Properties.Resources.Es_teh_manis;
            this.pb_tehmanis.Location = new System.Drawing.Point(9, 6);
            this.pb_tehmanis.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pb_tehmanis.Name = "pb_tehmanis";
            this.pb_tehmanis.Size = new System.Drawing.Size(149, 120);
            this.pb_tehmanis.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_tehmanis.TabIndex = 21;
            this.pb_tehmanis.TabStop = false;
            // 
            // pb_buah
            // 
            this.pb_buah.Image = global::ALP.Properties.Resources.Es_Buah;
            this.pb_buah.Location = new System.Drawing.Point(9, 6);
            this.pb_buah.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pb_buah.Name = "pb_buah";
            this.pb_buah.Size = new System.Drawing.Size(149, 120);
            this.pb_buah.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_buah.TabIndex = 21;
            this.pb_buah.TabStop = false;
            // 
            // pb_jeruk
            // 
            this.pb_jeruk.Image = global::ALP.Properties.Resources.Es_Jeruk;
            this.pb_jeruk.Location = new System.Drawing.Point(9, 6);
            this.pb_jeruk.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pb_jeruk.Name = "pb_jeruk";
            this.pb_jeruk.Size = new System.Drawing.Size(149, 120);
            this.pb_jeruk.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_jeruk.TabIndex = 21;
            this.pb_jeruk.TabStop = false;
            // 
            // pb_degan
            // 
            this.pb_degan.Image = global::ALP.Properties.Resources.Es_Degan;
            this.pb_degan.Location = new System.Drawing.Point(9, 6);
            this.pb_degan.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pb_degan.Name = "pb_degan";
            this.pb_degan.Size = new System.Drawing.Size(149, 120);
            this.pb_degan.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_degan.TabIndex = 21;
            this.pb_degan.TabStop = false;
            // 
            // pb_air
            // 
            this.pb_air.Image = global::ALP.Properties.Resources.Air_Mineral;
            this.pb_air.Location = new System.Drawing.Point(9, 6);
            this.pb_air.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pb_air.Name = "pb_air";
            this.pb_air.Size = new System.Drawing.Size(149, 120);
            this.pb_air.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_air.TabIndex = 21;
            this.pb_air.TabStop = false;
            // 
            // FormDrink
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.Snow;
            this.ClientSize = new System.Drawing.Size(1359, 1050);
            this.Controls.Add(this.stat_date);
            this.Controls.Add(this.panel_naga);
            this.Controls.Add(this.panel_sirsak);
            this.Controls.Add(this.panel_mangga);
            this.Controls.Add(this.panel_cendol);
            this.Controls.Add(this.panel_tehtarik);
            this.Controls.Add(this.panel_tehtawar);
            this.Controls.Add(this.panel_alpukat);
            this.Controls.Add(this.panel_jernip);
            this.Controls.Add(this.panel_jahe);
            this.Controls.Add(this.panel_tehmanis);
            this.Controls.Add(this.panel_buah);
            this.Controls.Add(this.panel_jeruk);
            this.Controls.Add(this.panel_degan);
            this.Controls.Add(this.panel_air);
            this.Controls.Add(this.lb_staffID);
            this.Controls.Add(this.lb_tableNo);
            this.Controls.Add(this.btn_Next);
            this.Controls.Add(this.tb_totalP);
            this.Controls.Add(this.tb_totalQ);
            this.Controls.Add(this.lb_totalP);
            this.Controls.Add(this.lb_totalQ);
            this.Controls.Add(this.dgv_pesanan);
            this.Controls.Add(this.lb_daftarP);
            this.Controls.Add(this.lb_noTable);
            this.Controls.Add(this.lb_ID);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "FormDrink";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "FormDrink";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormDrink_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_pesanan)).EndInit();
            this.panel_tehtawar.ResumeLayout(false);
            this.panel_tehtawar.PerformLayout();
            this.panel_tehmanis.ResumeLayout(false);
            this.panel_tehmanis.PerformLayout();
            this.panel_air.ResumeLayout(false);
            this.panel_air.PerformLayout();
            this.panel_cendol.ResumeLayout(false);
            this.panel_cendol.PerformLayout();
            this.panel_jernip.ResumeLayout(false);
            this.panel_jernip.PerformLayout();
            this.panel_jeruk.ResumeLayout(false);
            this.panel_jeruk.PerformLayout();
            this.panel_sirsak.ResumeLayout(false);
            this.panel_sirsak.PerformLayout();
            this.panel_tehtarik.ResumeLayout(false);
            this.panel_tehtarik.PerformLayout();
            this.panel_alpukat.ResumeLayout(false);
            this.panel_alpukat.PerformLayout();
            this.panel_jahe.ResumeLayout(false);
            this.panel_jahe.PerformLayout();
            this.panel_buah.ResumeLayout(false);
            this.panel_buah.PerformLayout();
            this.panel_degan.ResumeLayout(false);
            this.panel_degan.PerformLayout();
            this.panel_naga.ResumeLayout(false);
            this.panel_naga.PerformLayout();
            this.panel_mangga.ResumeLayout(false);
            this.panel_mangga.PerformLayout();
            this.stat_date.ResumeLayout(false);
            this.stat_date.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_naga)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_sirsak)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_mangga)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_cendol)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tektarik)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tehtawar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_alpukat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_jernip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_jahe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tehmanis)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_buah)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_jeruk)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_degan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_air)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_staffID;
        private System.Windows.Forms.Label lb_tableNo;
        private System.Windows.Forms.Button btn_Next;
        private System.Windows.Forms.TextBox tb_totalP;
        private System.Windows.Forms.TextBox tb_totalQ;
        private System.Windows.Forms.Label lb_totalP;
        private System.Windows.Forms.Label lb_totalQ;
        private System.Windows.Forms.DataGridView dgv_pesanan;
        private System.Windows.Forms.Label lb_daftarP;
        private System.Windows.Forms.Label lb_noTable;
        private System.Windows.Forms.Label lb_ID;
        private System.Windows.Forms.Panel panel_tehtawar;
        private System.Windows.Forms.Button btn_minTehtawar;
        private System.Windows.Forms.Button btn_addTehtawar;
        private System.Windows.Forms.Label lb_pTehtawar;
        private System.Windows.Forms.Label lb_tehtawar;
        private System.Windows.Forms.PictureBox pb_tehtawar;
        private System.Windows.Forms.Panel panel_tehmanis;
        private System.Windows.Forms.Button btn_minTehmanis;
        private System.Windows.Forms.Button btn_addTehmanis;
        private System.Windows.Forms.Label lb_pTehmanis;
        private System.Windows.Forms.Label lb_tehmanis;
        private System.Windows.Forms.PictureBox pb_tehmanis;
        private System.Windows.Forms.Panel panel_air;
        private System.Windows.Forms.Button btn_minAir;
        private System.Windows.Forms.Button btn_addAir;
        private System.Windows.Forms.Label lb_pAir;
        private System.Windows.Forms.Label lb_air;
        private System.Windows.Forms.PictureBox pb_air;
        private System.Windows.Forms.Panel panel_cendol;
        private System.Windows.Forms.Button btn_minCendol;
        private System.Windows.Forms.Button btn_addCendol;
        private System.Windows.Forms.Label lb_pCendol;
        private System.Windows.Forms.Label lb_cendol;
        private System.Windows.Forms.PictureBox pb_cendol;
        private System.Windows.Forms.Panel panel_jernip;
        private System.Windows.Forms.Button btn_minJernip;
        private System.Windows.Forms.Button btn_addJernip;
        private System.Windows.Forms.Label lb_pJernip;
        private System.Windows.Forms.Label lb_jernip;
        private System.Windows.Forms.PictureBox pb_jernip;
        private System.Windows.Forms.Panel panel_jeruk;
        private System.Windows.Forms.Button btn_minJeruk;
        private System.Windows.Forms.Button btn_addJeruk;
        private System.Windows.Forms.Label lb_pJeruk;
        private System.Windows.Forms.Label lb_jeruk;
        private System.Windows.Forms.PictureBox pb_jeruk;
        private System.Windows.Forms.Panel panel_sirsak;
        private System.Windows.Forms.Button btn_minSirsak;
        private System.Windows.Forms.Button btn_addSirsak;
        private System.Windows.Forms.Label lb_pSirsak;
        private System.Windows.Forms.Label lb_sirsak;
        private System.Windows.Forms.PictureBox pb_sirsak;
        private System.Windows.Forms.Panel panel_tehtarik;
        private System.Windows.Forms.Button btn_minTehTarik;
        private System.Windows.Forms.Button btn_addTehtarik;
        private System.Windows.Forms.Label lb_pTehtarik;
        private System.Windows.Forms.Label lb_tehtarik;
        private System.Windows.Forms.PictureBox pb_tektarik;
        private System.Windows.Forms.Panel panel_alpukat;
        private System.Windows.Forms.Button btn_minAlpukat;
        private System.Windows.Forms.Button btn_addAlpukat;
        private System.Windows.Forms.Label lb_pAlpukat;
        private System.Windows.Forms.Label lb_alpukat;
        private System.Windows.Forms.PictureBox pb_alpukat;
        private System.Windows.Forms.Panel panel_jahe;
        private System.Windows.Forms.Button btn_minJahe;
        private System.Windows.Forms.Button btn_addJahe;
        private System.Windows.Forms.Label lb_pJahe;
        private System.Windows.Forms.Label lb_jahe;
        private System.Windows.Forms.PictureBox pb_jahe;
        private System.Windows.Forms.Panel panel_buah;
        private System.Windows.Forms.Button btn_minBuah;
        private System.Windows.Forms.Button btn_addBuah;
        private System.Windows.Forms.Label lb_pBuah;
        private System.Windows.Forms.Label lb_buah;
        private System.Windows.Forms.PictureBox pb_buah;
        private System.Windows.Forms.Panel panel_degan;
        private System.Windows.Forms.Button btn_minDegan;
        private System.Windows.Forms.Button btn_addDegan;
        private System.Windows.Forms.Label lb_pDegan;
        private System.Windows.Forms.Label lb_degan;
        private System.Windows.Forms.PictureBox pb_degan;
        private System.Windows.Forms.Panel panel_naga;
        private System.Windows.Forms.Button btn_minNaga;
        private System.Windows.Forms.Button btn_addNaga;
        private System.Windows.Forms.Label lb_pNaga;
        private System.Windows.Forms.Label lb_naga;
        private System.Windows.Forms.PictureBox pb_naga;
        private System.Windows.Forms.Panel panel_mangga;
        private System.Windows.Forms.Button btn_minMangga;
        private System.Windows.Forms.Button btn_addMangga;
        private System.Windows.Forms.Label lb_pMangga;
        private System.Windows.Forms.Label lb_mangga;
        private System.Windows.Forms.PictureBox pb_mangga;
        private System.Windows.Forms.StatusStrip stat_date;
        private System.Windows.Forms.ToolStripStatusLabel dateStatus;
        private System.Windows.Forms.Timer timer_kasir;
    }
}