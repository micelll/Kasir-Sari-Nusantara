﻿namespace ALP
{
    partial class FormNota
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormNota));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lb_kembalian = new System.Windows.Forms.Label();
            this.lb_bayar = new System.Windows.Forms.Label();
            this.lb_total = new System.Windows.Forms.Label();
            this.lb_srvcharge = new System.Windows.Forms.Label();
            this.lb_ppn = new System.Windows.Forms.Label();
            this.lb_diskon = new System.Windows.Forms.Label();
            this.lb_k = new System.Windows.Forms.Label();
            this.lb_paymentmethod = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lb_subtotal = new System.Windows.Forms.Label();
            this.lb_sub = new System.Windows.Forms.Label();
            this.lb_quantity = new System.Windows.Forms.Label();
            this.lb_nomeja = new System.Windows.Forms.Label();
            this.lb_tglwaktu = new System.Windows.Forms.Label();
            this.lb_kodepromo = new System.Windows.Forms.Label();
            this.dgv_daftarpesan = new System.Windows.Forms.DataGridView();
            this.label6 = new System.Windows.Forms.Label();
            this.lb_makandimana = new System.Windows.Forms.Label();
            this.lb_idpegawai = new System.Windows.Forms.Label();
            this.lb_nostruk = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lb_struk = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.dateStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.lbl_TerimaKasih = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_daftarpesan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Snow;
            this.panel1.Controls.Add(this.lbl_TerimaKasih);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.lb_kembalian);
            this.panel1.Controls.Add(this.lb_bayar);
            this.panel1.Controls.Add(this.lb_total);
            this.panel1.Controls.Add(this.lb_srvcharge);
            this.panel1.Controls.Add(this.lb_ppn);
            this.panel1.Controls.Add(this.lb_diskon);
            this.panel1.Controls.Add(this.lb_k);
            this.panel1.Controls.Add(this.lb_paymentmethod);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.lb_subtotal);
            this.panel1.Controls.Add(this.lb_sub);
            this.panel1.Controls.Add(this.lb_quantity);
            this.panel1.Controls.Add(this.lb_nomeja);
            this.panel1.Controls.Add(this.lb_tglwaktu);
            this.panel1.Controls.Add(this.lb_kodepromo);
            this.panel1.Controls.Add(this.dgv_daftarpesan);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.lb_makandimana);
            this.panel1.Controls.Add(this.lb_idpegawai);
            this.panel1.Controls.Add(this.lb_nostruk);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.lb_struk);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(307, 15);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(449, 924);
            this.panel1.TabIndex = 65;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(-3, 602);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(521, 20);
            this.label7.TabIndex = 30;
            this.label7.Text = " - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - " +
    "- - - - - - - - - - - - - - - -  ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(-4, 262);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(521, 20);
            this.label5.TabIndex = 29;
            this.label5.Text = " - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - " +
    "- - - - - - - - - - - - - - - -  ";
            // 
            // lb_kembalian
            // 
            this.lb_kembalian.AutoSize = true;
            this.lb_kembalian.Location = new System.Drawing.Point(270, 823);
            this.lb_kembalian.Name = "lb_kembalian";
            this.lb_kembalian.Size = new System.Drawing.Size(81, 20);
            this.lb_kembalian.TabIndex = 28;
            this.lb_kembalian.Text = "kembalian";
            // 
            // lb_bayar
            // 
            this.lb_bayar.AutoSize = true;
            this.lb_bayar.Location = new System.Drawing.Point(270, 793);
            this.lb_bayar.Name = "lb_bayar";
            this.lb_bayar.Size = new System.Drawing.Size(48, 20);
            this.lb_bayar.TabIndex = 27;
            this.lb_bayar.Text = "bayar";
            // 
            // lb_total
            // 
            this.lb_total.AutoSize = true;
            this.lb_total.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_total.Location = new System.Drawing.Point(270, 763);
            this.lb_total.Name = "lb_total";
            this.lb_total.Size = new System.Drawing.Size(45, 20);
            this.lb_total.TabIndex = 26;
            this.lb_total.Text = "total";
            // 
            // lb_srvcharge
            // 
            this.lb_srvcharge.AutoSize = true;
            this.lb_srvcharge.Location = new System.Drawing.Point(270, 733);
            this.lb_srvcharge.Name = "lb_srvcharge";
            this.lb_srvcharge.Size = new System.Drawing.Size(58, 20);
            this.lb_srvcharge.TabIndex = 25;
            this.lb_srvcharge.Text = "service";
            // 
            // lb_ppn
            // 
            this.lb_ppn.AutoSize = true;
            this.lb_ppn.Location = new System.Drawing.Point(270, 703);
            this.lb_ppn.Name = "lb_ppn";
            this.lb_ppn.Size = new System.Drawing.Size(36, 20);
            this.lb_ppn.TabIndex = 24;
            this.lb_ppn.Text = "ppn";
            // 
            // lb_diskon
            // 
            this.lb_diskon.AutoSize = true;
            this.lb_diskon.Location = new System.Drawing.Point(270, 673);
            this.lb_diskon.Name = "lb_diskon";
            this.lb_diskon.Size = new System.Drawing.Size(55, 20);
            this.lb_diskon.TabIndex = 23;
            this.lb_diskon.Text = "diskon";
            // 
            // lb_k
            // 
            this.lb_k.AutoSize = true;
            this.lb_k.Location = new System.Drawing.Point(75, 823);
            this.lb_k.Name = "lb_k";
            this.lb_k.Size = new System.Drawing.Size(83, 20);
            this.lb_k.TabIndex = 22;
            this.lb_k.Text = "Kembalian";
            // 
            // lb_paymentmethod
            // 
            this.lb_paymentmethod.AutoSize = true;
            this.lb_paymentmethod.Location = new System.Drawing.Point(75, 793);
            this.lb_paymentmethod.Name = "lb_paymentmethod";
            this.lb_paymentmethod.Size = new System.Drawing.Size(102, 20);
            this.lb_paymentmethod.TabIndex = 21;
            this.lb_paymentmethod.Text = "methodbayar";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(75, 763);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(64, 20);
            this.label12.TabIndex = 20;
            this.label12.Text = "TOTAL";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(75, 733);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(159, 20);
            this.label11.TabIndex = 19;
            this.label11.Text = "Service charges (5%)";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(75, 703);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(86, 20);
            this.label10.TabIndex = 18;
            this.label10.Text = "PPN (10%)";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(75, 673);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(58, 20);
            this.label9.TabIndex = 17;
            this.label9.Text = "Diskon";
            // 
            // lb_subtotal
            // 
            this.lb_subtotal.AutoSize = true;
            this.lb_subtotal.Location = new System.Drawing.Point(270, 643);
            this.lb_subtotal.Name = "lb_subtotal";
            this.lb_subtotal.Size = new System.Drawing.Size(66, 20);
            this.lb_subtotal.TabIndex = 16;
            this.lb_subtotal.Text = "subtotal";
            // 
            // lb_sub
            // 
            this.lb_sub.AutoSize = true;
            this.lb_sub.Location = new System.Drawing.Point(75, 643);
            this.lb_sub.Name = "lb_sub";
            this.lb_sub.Size = new System.Drawing.Size(69, 20);
            this.lb_sub.TabIndex = 15;
            this.lb_sub.Text = "Subtotal";
            // 
            // lb_quantity
            // 
            this.lb_quantity.AutoSize = true;
            this.lb_quantity.Location = new System.Drawing.Point(126, 581);
            this.lb_quantity.Name = "lb_quantity";
            this.lb_quantity.Size = new System.Drawing.Size(65, 20);
            this.lb_quantity.TabIndex = 14;
            this.lb_quantity.Text = "quantity";
            // 
            // lb_nomeja
            // 
            this.lb_nomeja.AutoSize = true;
            this.lb_nomeja.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_nomeja.Location = new System.Drawing.Point(126, 237);
            this.lb_nomeja.Name = "lb_nomeja";
            this.lb_nomeja.Size = new System.Drawing.Size(43, 15);
            this.lb_nomeja.TabIndex = 13;
            this.lb_nomeja.Text = "nomor";
            // 
            // lb_tglwaktu
            // 
            this.lb_tglwaktu.AutoSize = true;
            this.lb_tglwaktu.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_tglwaktu.Location = new System.Drawing.Point(126, 217);
            this.lb_tglwaktu.Name = "lb_tglwaktu";
            this.lb_tglwaktu.Size = new System.Drawing.Size(55, 15);
            this.lb_tglwaktu.TabIndex = 12;
            this.lb_tglwaktu.Text = "tgl waktu";
            // 
            // lb_kodepromo
            // 
            this.lb_kodepromo.AutoSize = true;
            this.lb_kodepromo.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_kodepromo.Location = new System.Drawing.Point(126, 197);
            this.lb_kodepromo.Name = "lb_kodepromo";
            this.lb_kodepromo.Size = new System.Drawing.Size(43, 15);
            this.lb_kodepromo.TabIndex = 11;
            this.lb_kodepromo.Text = "promo";
            // 
            // dgv_daftarpesan
            // 
            this.dgv_daftarpesan.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_daftarpesan.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_daftarpesan.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgv_daftarpesan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_daftarpesan.Location = new System.Drawing.Point(27, 328);
            this.dgv_daftarpesan.Margin = new System.Windows.Forms.Padding(2);
            this.dgv_daftarpesan.Name = "dgv_daftarpesan";
            this.dgv_daftarpesan.RowHeadersVisible = false;
            this.dgv_daftarpesan.RowHeadersWidth = 51;
            this.dgv_daftarpesan.RowTemplate.Height = 24;
            this.dgv_daftarpesan.Size = new System.Drawing.Size(398, 244);
            this.dgv_daftarpesan.TabIndex = 10;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(26, 582);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 20);
            this.label6.TabIndex = 9;
            this.label6.Text = "Total Menu";
            // 
            // lb_makandimana
            // 
            this.lb_makandimana.AutoSize = true;
            this.lb_makandimana.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_makandimana.Location = new System.Drawing.Point(26, 294);
            this.lb_makandimana.Name = "lb_makandimana";
            this.lb_makandimana.Size = new System.Drawing.Size(67, 20);
            this.lb_makandimana.TabIndex = 8;
            this.lb_makandimana.Text = "Dine In";
            // 
            // lb_idpegawai
            // 
            this.lb_idpegawai.AutoSize = true;
            this.lb_idpegawai.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_idpegawai.Location = new System.Drawing.Point(126, 177);
            this.lb_idpegawai.Name = "lb_idpegawai";
            this.lb_idpegawai.Size = new System.Drawing.Size(67, 15);
            this.lb_idpegawai.TabIndex = 7;
            this.lb_idpegawai.Text = "id pegawai";
            // 
            // lb_nostruk
            // 
            this.lb_nostruk.AutoSize = true;
            this.lb_nostruk.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_nostruk.Location = new System.Drawing.Point(126, 153);
            this.lb_nostruk.Name = "lb_nostruk";
            this.lb_nostruk.Size = new System.Drawing.Size(44, 15);
            this.lb_nostruk.TabIndex = 6;
            this.lb_nostruk.Text = "id nota";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(20, 237);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 15);
            this.label4.TabIndex = 5;
            this.label4.Text = "No Meja        :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(20, 217);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 15);
            this.label3.TabIndex = 4;
            this.label3.Text = "Tanggal         :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(20, 197);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "Kode Promo :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(20, 177);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "ID Pegawai    : ";
            // 
            // lb_struk
            // 
            this.lb_struk.AutoSize = true;
            this.lb_struk.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_struk.Location = new System.Drawing.Point(20, 153);
            this.lb_struk.Name = "lb_struk";
            this.lb_struk.Size = new System.Drawing.Size(81, 15);
            this.lb_struk.TabIndex = 1;
            this.lb_struk.Text = "No Struk        :";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(128, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(200, 173);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dateStatus});
            this.statusStrip1.Location = new System.Drawing.Point(0, 939);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1046, 32);
            this.statusStrip1.TabIndex = 66;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // dateStatus
            // 
            this.dateStatus.Name = "dateStatus";
            this.dateStatus.Size = new System.Drawing.Size(179, 25);
            this.dateStatus.Text = "toolStripStatusLabel1";
            // 
            // lbl_TerimaKasih
            // 
            this.lbl_TerimaKasih.AutoSize = true;
            this.lbl_TerimaKasih.Font = new System.Drawing.Font("Palatino Linotype", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TerimaKasih.Location = new System.Drawing.Point(141, 866);
            this.lbl_TerimaKasih.Name = "lbl_TerimaKasih";
            this.lbl_TerimaKasih.Size = new System.Drawing.Size(129, 27);
            this.lbl_TerimaKasih.TabIndex = 31;
            this.lbl_TerimaKasih.Text = "Terima Kasih";
            // 
            // FormNota
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(1072, 965);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "FormNota";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "FormNota";
            this.Load += new System.EventHandler(this.FormNota_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_daftarpesan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lb_struk;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel dateStatus;
        private System.Windows.Forms.Label lb_idpegawai;
        private System.Windows.Forms.Label lb_nostruk;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lb_makandimana;
        private System.Windows.Forms.DataGridView dgv_daftarpesan;
        private System.Windows.Forms.Label lb_nomeja;
        private System.Windows.Forms.Label lb_tglwaktu;
        private System.Windows.Forms.Label lb_kodepromo;
        private System.Windows.Forms.Label lb_quantity;
        private System.Windows.Forms.Label lb_subtotal;
        private System.Windows.Forms.Label lb_sub;
        private System.Windows.Forms.Label lb_paymentmethod;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lb_ppn;
        private System.Windows.Forms.Label lb_diskon;
        private System.Windows.Forms.Label lb_k;
        private System.Windows.Forms.Label lb_bayar;
        private System.Windows.Forms.Label lb_total;
        private System.Windows.Forms.Label lb_srvcharge;
        private System.Windows.Forms.Label lb_kembalian;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbl_TerimaKasih;
    }
}