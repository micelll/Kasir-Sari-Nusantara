﻿namespace ALP
{
    partial class FormTable
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel_tableNo = new System.Windows.Forms.Panel();
            this.btn_24 = new System.Windows.Forms.Button();
            this.btn_23 = new System.Windows.Forms.Button();
            this.btn_22 = new System.Windows.Forms.Button();
            this.btn_21 = new System.Windows.Forms.Button();
            this.btn_20 = new System.Windows.Forms.Button();
            this.btn_19 = new System.Windows.Forms.Button();
            this.btn_18 = new System.Windows.Forms.Button();
            this.btn_17 = new System.Windows.Forms.Button();
            this.btn_16 = new System.Windows.Forms.Button();
            this.btn_15 = new System.Windows.Forms.Button();
            this.btn_14 = new System.Windows.Forms.Button();
            this.btn_13 = new System.Windows.Forms.Button();
            this.btn_12 = new System.Windows.Forms.Button();
            this.btn_11 = new System.Windows.Forms.Button();
            this.btn_10 = new System.Windows.Forms.Button();
            this.btn_09 = new System.Windows.Forms.Button();
            this.btn_08 = new System.Windows.Forms.Button();
            this.btn_07 = new System.Windows.Forms.Button();
            this.btn_06 = new System.Windows.Forms.Button();
            this.btn_05 = new System.Windows.Forms.Button();
            this.btn_04 = new System.Windows.Forms.Button();
            this.btn_03 = new System.Windows.Forms.Button();
            this.btn_02 = new System.Windows.Forms.Button();
            this.btn_01 = new System.Windows.Forms.Button();
            this.btn_00 = new System.Windows.Forms.Button();
            this.lb_staffID = new System.Windows.Forms.Label();
            this.lb_tableNo = new System.Windows.Forms.Label();
            this.btn_Next = new System.Windows.Forms.Button();
            this.tb_totalP = new System.Windows.Forms.TextBox();
            this.tb_totalQ = new System.Windows.Forms.TextBox();
            this.lb_totalP = new System.Windows.Forms.Label();
            this.lb_totalQ = new System.Windows.Forms.Label();
            this.dgv_pesanan = new System.Windows.Forms.DataGridView();
            this.lb_daftarP = new System.Windows.Forms.Label();
            this.lb_noTable = new System.Windows.Forms.Label();
            this.lb_ID = new System.Windows.Forms.Label();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.dateStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel_tableNo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_pesanan)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_tableNo
            // 
            this.panel_tableNo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel_tableNo.Controls.Add(this.btn_24);
            this.panel_tableNo.Controls.Add(this.btn_23);
            this.panel_tableNo.Controls.Add(this.btn_22);
            this.panel_tableNo.Controls.Add(this.btn_21);
            this.panel_tableNo.Controls.Add(this.btn_20);
            this.panel_tableNo.Controls.Add(this.btn_19);
            this.panel_tableNo.Controls.Add(this.btn_18);
            this.panel_tableNo.Controls.Add(this.btn_17);
            this.panel_tableNo.Controls.Add(this.btn_16);
            this.panel_tableNo.Controls.Add(this.btn_15);
            this.panel_tableNo.Controls.Add(this.btn_14);
            this.panel_tableNo.Controls.Add(this.btn_13);
            this.panel_tableNo.Controls.Add(this.btn_12);
            this.panel_tableNo.Controls.Add(this.btn_11);
            this.panel_tableNo.Controls.Add(this.btn_10);
            this.panel_tableNo.Controls.Add(this.btn_09);
            this.panel_tableNo.Controls.Add(this.btn_08);
            this.panel_tableNo.Controls.Add(this.btn_07);
            this.panel_tableNo.Controls.Add(this.btn_06);
            this.panel_tableNo.Controls.Add(this.btn_05);
            this.panel_tableNo.Controls.Add(this.btn_04);
            this.panel_tableNo.Controls.Add(this.btn_03);
            this.panel_tableNo.Controls.Add(this.btn_02);
            this.panel_tableNo.Controls.Add(this.btn_01);
            this.panel_tableNo.Controls.Add(this.btn_00);
            this.panel_tableNo.Location = new System.Drawing.Point(72, 119);
            this.panel_tableNo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_tableNo.Name = "panel_tableNo";
            this.panel_tableNo.Size = new System.Drawing.Size(516, 572);
            this.panel_tableNo.TabIndex = 59;
            // 
            // btn_24
            // 
            this.btn_24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btn_24.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_24.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_24.Location = new System.Drawing.Point(419, 479);
            this.btn_24.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_24.Name = "btn_24";
            this.btn_24.Size = new System.Drawing.Size(75, 75);
            this.btn_24.TabIndex = 46;
            this.btn_24.Text = "24";
            this.btn_24.UseVisualStyleBackColor = false;
            this.btn_24.Click += new System.EventHandler(this.btn_24_Click);
            // 
            // btn_23
            // 
            this.btn_23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btn_23.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_23.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_23.Location = new System.Drawing.Point(323, 479);
            this.btn_23.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_23.Name = "btn_23";
            this.btn_23.Size = new System.Drawing.Size(75, 75);
            this.btn_23.TabIndex = 45;
            this.btn_23.Text = "23";
            this.btn_23.UseVisualStyleBackColor = false;
            this.btn_23.Click += new System.EventHandler(this.btn_23_Click);
            // 
            // btn_22
            // 
            this.btn_22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btn_22.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_22.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_22.Location = new System.Drawing.Point(221, 479);
            this.btn_22.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_22.Name = "btn_22";
            this.btn_22.Size = new System.Drawing.Size(75, 75);
            this.btn_22.TabIndex = 44;
            this.btn_22.Text = "22";
            this.btn_22.UseVisualStyleBackColor = false;
            this.btn_22.Click += new System.EventHandler(this.btn_22_Click);
            // 
            // btn_21
            // 
            this.btn_21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btn_21.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_21.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_21.Location = new System.Drawing.Point(123, 479);
            this.btn_21.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_21.Name = "btn_21";
            this.btn_21.Size = new System.Drawing.Size(75, 75);
            this.btn_21.TabIndex = 43;
            this.btn_21.Text = "21";
            this.btn_21.UseVisualStyleBackColor = false;
            this.btn_21.Click += new System.EventHandler(this.btn_21_Click);
            // 
            // btn_20
            // 
            this.btn_20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btn_20.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_20.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_20.Location = new System.Drawing.Point(419, 386);
            this.btn_20.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_20.Name = "btn_20";
            this.btn_20.Size = new System.Drawing.Size(75, 75);
            this.btn_20.TabIndex = 42;
            this.btn_20.Text = "20";
            this.btn_20.UseVisualStyleBackColor = false;
            this.btn_20.Click += new System.EventHandler(this.btn_20_Click);
            // 
            // btn_19
            // 
            this.btn_19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btn_19.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_19.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_19.Location = new System.Drawing.Point(323, 386);
            this.btn_19.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_19.Name = "btn_19";
            this.btn_19.Size = new System.Drawing.Size(75, 75);
            this.btn_19.TabIndex = 41;
            this.btn_19.Text = "19";
            this.btn_19.UseVisualStyleBackColor = false;
            this.btn_19.Click += new System.EventHandler(this.btn_19_Click);
            // 
            // btn_18
            // 
            this.btn_18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btn_18.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_18.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_18.Location = new System.Drawing.Point(221, 386);
            this.btn_18.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_18.Name = "btn_18";
            this.btn_18.Size = new System.Drawing.Size(75, 75);
            this.btn_18.TabIndex = 40;
            this.btn_18.Text = "18";
            this.btn_18.UseVisualStyleBackColor = false;
            this.btn_18.Click += new System.EventHandler(this.btn_18_Click);
            // 
            // btn_17
            // 
            this.btn_17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btn_17.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_17.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_17.Location = new System.Drawing.Point(123, 386);
            this.btn_17.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_17.Name = "btn_17";
            this.btn_17.Size = new System.Drawing.Size(75, 75);
            this.btn_17.TabIndex = 39;
            this.btn_17.Text = "17";
            this.btn_17.UseVisualStyleBackColor = false;
            this.btn_17.Click += new System.EventHandler(this.btn_17_Click);
            // 
            // btn_16
            // 
            this.btn_16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btn_16.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_16.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_16.Location = new System.Drawing.Point(419, 292);
            this.btn_16.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_16.Name = "btn_16";
            this.btn_16.Size = new System.Drawing.Size(75, 75);
            this.btn_16.TabIndex = 38;
            this.btn_16.Text = "16";
            this.btn_16.UseVisualStyleBackColor = false;
            this.btn_16.Click += new System.EventHandler(this.btn_16_Click);
            // 
            // btn_15
            // 
            this.btn_15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btn_15.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_15.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_15.Location = new System.Drawing.Point(323, 292);
            this.btn_15.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_15.Name = "btn_15";
            this.btn_15.Size = new System.Drawing.Size(75, 75);
            this.btn_15.TabIndex = 37;
            this.btn_15.Text = "15";
            this.btn_15.UseVisualStyleBackColor = false;
            this.btn_15.Click += new System.EventHandler(this.btn_15_Click);
            // 
            // btn_14
            // 
            this.btn_14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btn_14.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_14.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_14.Location = new System.Drawing.Point(221, 292);
            this.btn_14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_14.Name = "btn_14";
            this.btn_14.Size = new System.Drawing.Size(75, 75);
            this.btn_14.TabIndex = 36;
            this.btn_14.Text = "14";
            this.btn_14.UseVisualStyleBackColor = false;
            this.btn_14.Click += new System.EventHandler(this.btn_14_Click);
            // 
            // btn_13
            // 
            this.btn_13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btn_13.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_13.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_13.Location = new System.Drawing.Point(123, 292);
            this.btn_13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_13.Name = "btn_13";
            this.btn_13.Size = new System.Drawing.Size(75, 75);
            this.btn_13.TabIndex = 35;
            this.btn_13.Text = "13";
            this.btn_13.UseVisualStyleBackColor = false;
            this.btn_13.Click += new System.EventHandler(this.btn_13_Click);
            // 
            // btn_12
            // 
            this.btn_12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btn_12.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_12.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_12.Location = new System.Drawing.Point(419, 199);
            this.btn_12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_12.Name = "btn_12";
            this.btn_12.Size = new System.Drawing.Size(75, 75);
            this.btn_12.TabIndex = 34;
            this.btn_12.Text = "12";
            this.btn_12.UseVisualStyleBackColor = false;
            this.btn_12.Click += new System.EventHandler(this.btn_12_Click);
            // 
            // btn_11
            // 
            this.btn_11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btn_11.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_11.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_11.Location = new System.Drawing.Point(323, 199);
            this.btn_11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_11.Name = "btn_11";
            this.btn_11.Size = new System.Drawing.Size(75, 75);
            this.btn_11.TabIndex = 33;
            this.btn_11.Text = "11";
            this.btn_11.UseVisualStyleBackColor = false;
            this.btn_11.Click += new System.EventHandler(this.btn_11_Click);
            // 
            // btn_10
            // 
            this.btn_10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btn_10.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_10.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_10.Location = new System.Drawing.Point(221, 199);
            this.btn_10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_10.Name = "btn_10";
            this.btn_10.Size = new System.Drawing.Size(75, 75);
            this.btn_10.TabIndex = 32;
            this.btn_10.Text = "10";
            this.btn_10.UseVisualStyleBackColor = false;
            this.btn_10.Click += new System.EventHandler(this.btn_10_Click);
            // 
            // btn_09
            // 
            this.btn_09.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btn_09.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_09.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_09.Location = new System.Drawing.Point(123, 199);
            this.btn_09.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_09.Name = "btn_09";
            this.btn_09.Size = new System.Drawing.Size(75, 75);
            this.btn_09.TabIndex = 31;
            this.btn_09.Text = "09";
            this.btn_09.UseVisualStyleBackColor = false;
            this.btn_09.Click += new System.EventHandler(this.btn_09_Click);
            // 
            // btn_08
            // 
            this.btn_08.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btn_08.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_08.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_08.Location = new System.Drawing.Point(419, 106);
            this.btn_08.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_08.Name = "btn_08";
            this.btn_08.Size = new System.Drawing.Size(75, 75);
            this.btn_08.TabIndex = 30;
            this.btn_08.Text = "08";
            this.btn_08.UseVisualStyleBackColor = false;
            this.btn_08.Click += new System.EventHandler(this.btn_08_Click);
            // 
            // btn_07
            // 
            this.btn_07.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btn_07.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_07.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_07.Location = new System.Drawing.Point(323, 106);
            this.btn_07.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_07.Name = "btn_07";
            this.btn_07.Size = new System.Drawing.Size(75, 75);
            this.btn_07.TabIndex = 29;
            this.btn_07.Text = "07";
            this.btn_07.UseVisualStyleBackColor = false;
            this.btn_07.Click += new System.EventHandler(this.btn_07_Click);
            // 
            // btn_06
            // 
            this.btn_06.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btn_06.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_06.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_06.Location = new System.Drawing.Point(221, 106);
            this.btn_06.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_06.Name = "btn_06";
            this.btn_06.Size = new System.Drawing.Size(75, 75);
            this.btn_06.TabIndex = 28;
            this.btn_06.Text = "06";
            this.btn_06.UseVisualStyleBackColor = false;
            this.btn_06.Click += new System.EventHandler(this.btn_06_Click);
            // 
            // btn_05
            // 
            this.btn_05.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btn_05.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_05.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_05.Location = new System.Drawing.Point(123, 106);
            this.btn_05.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_05.Name = "btn_05";
            this.btn_05.Size = new System.Drawing.Size(75, 75);
            this.btn_05.TabIndex = 27;
            this.btn_05.Text = "05";
            this.btn_05.UseVisualStyleBackColor = false;
            this.btn_05.Click += new System.EventHandler(this.btn_05_Click);
            // 
            // btn_04
            // 
            this.btn_04.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btn_04.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_04.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_04.Location = new System.Drawing.Point(419, 12);
            this.btn_04.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_04.Name = "btn_04";
            this.btn_04.Size = new System.Drawing.Size(75, 75);
            this.btn_04.TabIndex = 26;
            this.btn_04.Text = "04";
            this.btn_04.UseVisualStyleBackColor = false;
            this.btn_04.Click += new System.EventHandler(this.btn_04_Click);
            // 
            // btn_03
            // 
            this.btn_03.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btn_03.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_03.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_03.Location = new System.Drawing.Point(323, 12);
            this.btn_03.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_03.Name = "btn_03";
            this.btn_03.Size = new System.Drawing.Size(75, 75);
            this.btn_03.TabIndex = 25;
            this.btn_03.Text = "03";
            this.btn_03.UseVisualStyleBackColor = false;
            this.btn_03.Click += new System.EventHandler(this.btn_03_Click);
            // 
            // btn_02
            // 
            this.btn_02.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btn_02.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_02.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_02.Location = new System.Drawing.Point(221, 12);
            this.btn_02.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_02.Name = "btn_02";
            this.btn_02.Size = new System.Drawing.Size(75, 75);
            this.btn_02.TabIndex = 24;
            this.btn_02.Text = "02";
            this.btn_02.UseVisualStyleBackColor = false;
            this.btn_02.Click += new System.EventHandler(this.btn_02_Click);
            // 
            // btn_01
            // 
            this.btn_01.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btn_01.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_01.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_01.Location = new System.Drawing.Point(123, 12);
            this.btn_01.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_01.Name = "btn_01";
            this.btn_01.Size = new System.Drawing.Size(75, 75);
            this.btn_01.TabIndex = 23;
            this.btn_01.Text = "01";
            this.btn_01.UseVisualStyleBackColor = false;
            this.btn_01.Click += new System.EventHandler(this.btn_01_Click);
            // 
            // btn_00
            // 
            this.btn_00.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btn_00.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_00.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_00.Location = new System.Drawing.Point(21, 12);
            this.btn_00.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_00.Name = "btn_00";
            this.btn_00.Size = new System.Drawing.Size(75, 75);
            this.btn_00.TabIndex = 22;
            this.btn_00.Text = "00";
            this.btn_00.UseVisualStyleBackColor = false;
            this.btn_00.Click += new System.EventHandler(this.btn_00_Click);
            // 
            // lb_staffID
            // 
            this.lb_staffID.AutoSize = true;
            this.lb_staffID.Location = new System.Drawing.Point(1023, 41);
            this.lb_staffID.Name = "lb_staffID";
            this.lb_staffID.Size = new System.Drawing.Size(19, 25);
            this.lb_staffID.TabIndex = 58;
            this.lb_staffID.Text = "-";
            // 
            // lb_tableNo
            // 
            this.lb_tableNo.AutoSize = true;
            this.lb_tableNo.Location = new System.Drawing.Point(1079, 88);
            this.lb_tableNo.Name = "lb_tableNo";
            this.lb_tableNo.Size = new System.Drawing.Size(19, 25);
            this.lb_tableNo.TabIndex = 57;
            this.lb_tableNo.Text = "-";
            // 
            // btn_Next
            // 
            this.btn_Next.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btn_Next.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Next.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Next.Location = new System.Drawing.Point(789, 705);
            this.btn_Next.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Next.Name = "btn_Next";
            this.btn_Next.Size = new System.Drawing.Size(116, 41);
            this.btn_Next.TabIndex = 56;
            this.btn_Next.Text = "Next";
            this.btn_Next.UseVisualStyleBackColor = false;
            this.btn_Next.Click += new System.EventHandler(this.btn_Next_Click);
            // 
            // tb_totalP
            // 
            this.tb_totalP.Enabled = false;
            this.tb_totalP.Location = new System.Drawing.Point(789, 656);
            this.tb_totalP.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tb_totalP.Name = "tb_totalP";
            this.tb_totalP.Size = new System.Drawing.Size(188, 31);
            this.tb_totalP.TabIndex = 55;
            // 
            // tb_totalQ
            // 
            this.tb_totalQ.Enabled = false;
            this.tb_totalQ.Location = new System.Drawing.Point(789, 616);
            this.tb_totalQ.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tb_totalQ.Name = "tb_totalQ";
            this.tb_totalQ.Size = new System.Drawing.Size(188, 31);
            this.tb_totalQ.TabIndex = 54;
            // 
            // lb_totalP
            // 
            this.lb_totalP.AutoSize = true;
            this.lb_totalP.Location = new System.Drawing.Point(629, 656);
            this.lb_totalP.Name = "lb_totalP";
            this.lb_totalP.Size = new System.Drawing.Size(121, 25);
            this.lb_totalP.TabIndex = 53;
            this.lb_totalP.Text = "Total Price:";
            // 
            // lb_totalQ
            // 
            this.lb_totalQ.AutoSize = true;
            this.lb_totalQ.Location = new System.Drawing.Point(629, 616);
            this.lb_totalQ.Name = "lb_totalQ";
            this.lb_totalQ.Size = new System.Drawing.Size(152, 25);
            this.lb_totalQ.TabIndex = 52;
            this.lb_totalQ.Text = "Total Quantity:";
            // 
            // dgv_pesanan
            // 
            this.dgv_pesanan.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv_pesanan.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_pesanan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_pesanan.Location = new System.Drawing.Point(635, 171);
            this.dgv_pesanan.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dgv_pesanan.Name = "dgv_pesanan";
            this.dgv_pesanan.ReadOnly = true;
            this.dgv_pesanan.RowHeadersVisible = false;
            this.dgv_pesanan.RowHeadersWidth = 82;
            this.dgv_pesanan.RowTemplate.Height = 33;
            this.dgv_pesanan.Size = new System.Drawing.Size(651, 425);
            this.dgv_pesanan.TabIndex = 51;
            // 
            // lb_daftarP
            // 
            this.lb_daftarP.AutoSize = true;
            this.lb_daftarP.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_daftarP.Location = new System.Drawing.Point(629, 128);
            this.lb_daftarP.Name = "lb_daftarP";
            this.lb_daftarP.Size = new System.Drawing.Size(182, 25);
            this.lb_daftarP.TabIndex = 50;
            this.lb_daftarP.Text = "Daftar Pesanan:";
            // 
            // lb_noTable
            // 
            this.lb_noTable.AutoSize = true;
            this.lb_noTable.Location = new System.Drawing.Point(929, 86);
            this.lb_noTable.Name = "lb_noTable";
            this.lb_noTable.Size = new System.Drawing.Size(153, 25);
            this.lb_noTable.TabIndex = 49;
            this.lb_noTable.Text = "Table Number:";
            // 
            // lb_ID
            // 
            this.lb_ID.AutoSize = true;
            this.lb_ID.Location = new System.Drawing.Point(929, 41);
            this.lb_ID.Name = "lb_ID";
            this.lb_ID.Size = new System.Drawing.Size(88, 25);
            this.lb_ID.TabIndex = 48;
            this.lb_ID.Text = "Staff ID:";
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dateStatus});
            this.statusStrip1.Location = new System.Drawing.Point(0, 939);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 19, 0);
            this.statusStrip1.Size = new System.Drawing.Size(1355, 42);
            this.statusStrip1.TabIndex = 61;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // dateStatus
            // 
            this.dateStatus.Name = "dateStatus";
            this.dateStatus.Size = new System.Drawing.Size(237, 32);
            this.dateStatus.Text = "toolStripStatusLabel1";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick_1);
            // 
            // FormTable
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.Snow;
            this.ClientSize = new System.Drawing.Size(1355, 981);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.panel_tableNo);
            this.Controls.Add(this.lb_staffID);
            this.Controls.Add(this.lb_tableNo);
            this.Controls.Add(this.btn_Next);
            this.Controls.Add(this.tb_totalP);
            this.Controls.Add(this.tb_totalQ);
            this.Controls.Add(this.lb_totalP);
            this.Controls.Add(this.lb_totalQ);
            this.Controls.Add(this.dgv_pesanan);
            this.Controls.Add(this.lb_daftarP);
            this.Controls.Add(this.lb_noTable);
            this.Controls.Add(this.lb_ID);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "FormTable";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "FormTable";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormTable_Load);
            this.panel_tableNo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_pesanan)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel_tableNo;
        private System.Windows.Forms.Button btn_24;
        private System.Windows.Forms.Button btn_23;
        private System.Windows.Forms.Button btn_22;
        private System.Windows.Forms.Button btn_21;
        private System.Windows.Forms.Button btn_20;
        private System.Windows.Forms.Button btn_19;
        private System.Windows.Forms.Button btn_18;
        private System.Windows.Forms.Button btn_17;
        private System.Windows.Forms.Button btn_16;
        private System.Windows.Forms.Button btn_15;
        private System.Windows.Forms.Button btn_14;
        private System.Windows.Forms.Button btn_13;
        private System.Windows.Forms.Button btn_12;
        private System.Windows.Forms.Button btn_11;
        private System.Windows.Forms.Button btn_10;
        private System.Windows.Forms.Button btn_09;
        private System.Windows.Forms.Button btn_08;
        private System.Windows.Forms.Button btn_07;
        private System.Windows.Forms.Button btn_06;
        private System.Windows.Forms.Button btn_05;
        private System.Windows.Forms.Button btn_04;
        private System.Windows.Forms.Button btn_03;
        private System.Windows.Forms.Button btn_02;
        private System.Windows.Forms.Button btn_01;
        private System.Windows.Forms.Button btn_00;
        private System.Windows.Forms.Label lb_staffID;
        private System.Windows.Forms.Label lb_tableNo;
        private System.Windows.Forms.Button btn_Next;
        private System.Windows.Forms.TextBox tb_totalP;
        private System.Windows.Forms.TextBox tb_totalQ;
        private System.Windows.Forms.Label lb_totalP;
        private System.Windows.Forms.Label lb_totalQ;
        private System.Windows.Forms.DataGridView dgv_pesanan;
        private System.Windows.Forms.Label lb_daftarP;
        private System.Windows.Forms.Label lb_noTable;
        private System.Windows.Forms.Label lb_ID;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel dateStatus;
        private System.Windows.Forms.Timer timer1;
    }
}